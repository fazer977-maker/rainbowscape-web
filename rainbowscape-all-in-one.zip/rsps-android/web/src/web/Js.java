package web;

import org.teavm.jso.JSBody;
import org.teavm.jso.JSObject;

/**
 * Everything the game needs from the page. The matching JavaScript lives in static/index.html
 * (window.rs). Java arrays reach JavaScript as wrapper objects whose .data is the typed array.
 */
public final class Js {
	private Js() {}

	@JSBody(params = { "key" }, script = "return String(window.rs.cfg(key));")
	public static native String cfgStr(String key);

	@JSBody(params = { "key" }, script = "return window.rs.cfg(key) | 0;")
	public static native int cfgInt(String key);

	@JSBody(params = { "url" }, script = "return window.rs.wsOpen(url);")
	public static native JSObject wsOpen(String url);

	@JSBody(params = { "ws" }, script = "return ws.state;")
	public static native int wsState(JSObject ws);

	@JSBody(params = { "ws" }, script = "return ws.avail();")
	public static native int wsAvail(JSObject ws);

	@JSBody(params = { "ws", "dst", "off", "len" }, script = "return ws.read(dst.data, off, len);")
	public static native int wsRead(JSObject ws, byte[] dst, int off, int len);

	@JSBody(params = { "ws", "src", "off", "len" }, script = "ws.send(src.data, off, len);")
	public static native void wsSend(JSObject ws, byte[] src, int off, int len);

	@JSBody(params = { "ws" }, script = "ws.close();")
	public static native void wsClose(JSObject ws);

	@JSBody(params = { "px", "w", "h", "cx", "cy", "cw", "ch" }, script = "window.rs.present(px.data, w, h, cx, cy, cw, ch);")
	public static native void present(int[] px, int w, int h, int cx, int cy, int cw, int ch);

	@JSBody(params = {}, script = "return window.rs.viewW();")
	public static native int viewW();

	@JSBody(params = {}, script = "return window.rs.viewH();")
	public static native int viewH();

	@JSBody(params = { "font", "style", "size", "out" }, script = "window.rs.textMetrics(style, size, out.data);")
	public static native void textMetrics(String font, int style, int size, int[] out);

	@JSBody(params = { "text", "style", "size" }, script = "return window.rs.textWidth(text, style, size);")
	public static native int textWidth(String text, int style, int size);

	@JSBody(params = { "text", "style", "size", "tw", "th", "ascent", "alpha" }, script = "window.rs.glyphs(text, style, size, tw, th, ascent, alpha.data);")
	public static native void glyphs(String text, int style, int size, int tw, int th, int ascent, int[] alpha);

	@JSBody(params = {}, script = "return window.rs.inHas() ? 1 : 0;")
	public static native int inHas();

	@JSBody(params = {}, script = "return window.rs.inNext() | 0;")
	public static native int inNext();

	@JSBody(params = { "text" }, script = "window.rs.log(String(text));")
	public static native void log(String text);

	@JSBody(params = { "url" }, script = "window.open(url, '_blank');")
	public static native void openUrl(String url);

	@JSBody(params = { "title" }, script = "document.title = title;")
	public static native void setTitle(String title);

	@JSBody(params = { "n", "rate" }, script = "window.rs.audioFeed && window.rs.audioFeed(n, rate);")
	public static native void audioTick(int n, int rate);
}
