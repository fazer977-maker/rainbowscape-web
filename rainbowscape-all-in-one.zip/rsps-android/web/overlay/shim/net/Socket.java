package shim.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.teavm.jso.JSObject;
import web.Js;

/**
 * Browser replacement for java.net.Socket: a WebSocket to the bridge (proxy/ws-proxy.js), which
 * forwards the bytes to the real game port. The host is ignored; the bridge picks the server.
 */
public final class Socket {
	private final JSObject ws;
	private int timeoutMs = 30000;
	private boolean closed;

	public Socket(String host, int port) throws IOException {
		String base = Js.cfgStr("wsUrl");
		String url = base + (base.indexOf('?') >= 0 ? "&" : "?") + "port=" + port;
		this.ws = Js.wsOpen(url);
		long start = System.currentTimeMillis();
		while (true) {
			int s = Js.wsState(this.ws);
			if (s == 1) {
				break;
			}
			if (s == 2 || System.currentTimeMillis() - start > 15000L) {
				Js.wsClose(this.ws);
				throw new IOException("connect failed");
			}
			sleep(5);
		}
	}

	private static void sleep(long ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
		}
	}

	public void setSoTimeout(int ms) {
		this.timeoutMs = ms;
	}

	public void setTcpNoDelay(boolean on) {
	}

	public void close() {
		if (!this.closed) {
			this.closed = true;
			Js.wsClose(this.ws);
		}
	}

	public InputStream getInputStream() {
		return new InputStream() {
			@Override
			public int available() {
				return Js.wsAvail(Socket.this.ws);
			}

			@Override
			public int read() throws IOException {
				byte[] one = new byte[1];
				int n = read(one, 0, 1);
				return n <= 0 ? -1 : one[0] & 0xFF;
			}

			@Override
			public int read(byte[] b, int off, int len) throws IOException {
				if (len == 0) {
					return 0;
				}
				long start = System.currentTimeMillis();
				while (true) {
					int have = Js.wsAvail(Socket.this.ws);
					if (have > 0) {
						return Js.wsRead(Socket.this.ws, b, off, Math.min(len, have));
					}
					if (Socket.this.closed || Js.wsState(Socket.this.ws) == 2) {
						return -1;
					}
					if (Socket.this.timeoutMs > 0 && System.currentTimeMillis() - start > Socket.this.timeoutMs) {
						throw new IOException("read timed out");
					}
					sleep(2);
				}
			}
		};
	}

	public OutputStream getOutputStream() {
		return new OutputStream() {
			@Override
			public void write(int b) throws IOException {
				write(new byte[] { (byte) b }, 0, 1);
			}

			@Override
			public void write(byte[] b, int off, int len) throws IOException {
				if (Socket.this.closed || Js.wsState(Socket.this.ws) != 1) {
					throw new IOException("socket closed");
				}
				Js.wsSend(Socket.this.ws, b, off, len);
			}
		};
	}
}
