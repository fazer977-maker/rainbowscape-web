# Rainbow Scape site (publish this folder)
- `index.html` landing page, `rainbowscape.apk` Android download
- `play/` browser game: `index.html` + `rainbow.js` are built by the "Build web client" GitHub Action;
  edit `play/config.js` with your server address.
Netlify: import this repo, build command empty, publish directory `site`.
