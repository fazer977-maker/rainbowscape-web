package plugin;

import plugin.api.MiniMenuEntry;
import rt4.Component;
import rt4.JagString;
import rt4.Npc;
import rt4.Player;

/** Android build: the desktop plugin system is not included, all hooks are no-ops. */
public class PluginRepository {
    public static int lastMiniMenu;
    public static void reloadPlugins() {}
    public static void Init() {}
    public static void Update() {}
    public static void Draw() {}
    public static void LateDraw() {}
    public static void NPCOverheadDraw(Npc npc, int screenX, int screenY) {}
    public static void PlayerOverheadDraw(Player player, int screenX, int screenY) {}
    public static void ProcessCommand(JagString commandStr) {}
    public static void ComponentDraw(int componentIndex, Component component, int screenX, int screenY) {}
    public static void OnVarpUpdate(int id, int value) {}
    public static void OnXPUpdate(int skill, int xp) {}
    public static void OnLogout() {}
    public static void DrawMiniMenu(MiniMenuEntry entry) {}
    public static void OnMiniMenuCreate() {}
    public static void OnLogin() {}
    public static void OnKillingBlowNPC(int npcId, int x, int z) {}
    public static void SaveStorage() {}
}
