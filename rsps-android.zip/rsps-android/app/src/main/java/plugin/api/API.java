package plugin.api;

/** Android build: roof-visibility plugin hooks are disabled (defaults only). */
public class API {
    public static final int TILE_FLAG_UNDER_ROOF = 0x4;
    public static Runnable[] miniMenuCustomActions = new Runnable[10];
    public static final int DEFAULT_ROOF_VISIBILITY_GROUP_LIMIT = 2;
    public static int GetRoofVisibilityGroupLimit() { return DEFAULT_ROOF_VISIBILITY_GROUP_LIMIT; }
    public static boolean IsRoofVisibilityActive() { return false; }
    public static void DisableRoofVisibilityIfExpired() {}
    public static void EnsureRoofVisibilityBuffers() {}
    public static void ApplyRoofVisibilityRequests() {}
    public static boolean IsRoofVisibilityPicking() { return false; }
    public static int GetRoofVisibilityPickScreenX() { return 0; }
    public static int GetRoofVisibilityPickScreenY() { return 0; }
    public static void ReportRoofVisibilityTile(int sceneX, int sceneY, int plane) {}
    public static boolean IsRoofVisibilityLocPickable(long key) { return false; }
    public static void ReportRoofVisibilityLoc(long key, int plane) {}
    public static void BeginRoofVisibilityGroup(int group) {}
    public static void AddRoofVisibilityGroupTile(int group, int plane, int sceneX, int sceneY) {}
    public static void SetDestinationRoofTarget(int sceneX, int sceneY) {}
    public static void ClearDestinationRoofTarget() {}
}
