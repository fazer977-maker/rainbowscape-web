package app.rsps2009;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import rt4.Camera;

/** The game's drawing surface. Also turns touches into mouse/camera input and hosts the soft keyboard. */
public class GameSurface extends SurfaceView {

    private static final long LONG_PRESS_MS = 420;

    private enum State { IDLE, PENDING, DRAGGING, LONG, CAMERA, ROTATE, CHAT, IGNORE }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final float touchSlop;
    private final float density;
    private float scale = 1f;

    private State state = State.IDLE;
    private float downX, downY, lastX, lastY;
    // two-finger camera gesture
    private float camCx, camCy, camDist;
    private float wheelAccum;
    private float chatAccum;
    private double velYaw, velPitch;
    private long lastMoveMs;

    private final Runnable longPress = new Runnable() {
        @Override public void run() {
            if (state == State.PENDING) {
                state = State.LONG;
                GameEvents.move(downX, downY);
                GameEvents.press(downX, downY, shim.awt.event.MouseEvent.BUTTON3);
                GameEvents.release(downX, downY, shim.awt.event.MouseEvent.BUTTON3);
                performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
            }
        }
    };

    public GameSurface(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        touchSlop = 10 * density;
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    public void setRenderScale(float s) { scale = s; GameEvents.setScale(s); }

    // ----------------------------------------------------------------- touch

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                state = State.PENDING;
                GameEvents.move(downX, downY);
                handler.postDelayed(longPress, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    handler.removeCallbacks(longPress);
                    if (state == State.DRAGGING) {
                        GameEvents.release(lastX, lastY, shim.awt.event.MouseEvent.BUTTON1);
                    }
                    state = State.CAMERA;
                    camCx = (e.getX(0) + e.getX(1)) / 2f;
                    camCy = (e.getY(0) + e.getY(1)) / 2f;
                    camDist = dist(e);
                    wheelAccum = 0;
                } else {
                    state = State.IGNORE;
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (state == State.CAMERA && e.getPointerCount() >= 2) {
                    float cx = (e.getX(0) + e.getX(1)) / 2f;
                    float cy = (e.getY(0) + e.getY(1)) / 2f;
                    float dx = (cx - camCx) / scale;
                    float dy = (cy - camCy) / scale;
                    camCx = cx;
                    camCy = cy;
                    rt4.CameraSmoother.add(-dx * 1.6, dy * 1.0);
                    float d = dist(e);
                    if (d > 1f && camDist > 1f) {
                        int z = Math.round(Camera.ZOOM * (camDist / d));
                        Camera.ZOOM = Math.max(250, Math.min(1600, z));
                    }
                    camDist = d;
                    return true;
                }
                if (e.getPointerCount() == 1) {
                    float x = e.getX(), y = e.getY();
                    if (state == State.PENDING) {
                        float ddx = x - downX, ddy = y - downY;
                        if (ddx * ddx + ddy * ddy > touchSlop * touchSlop) {
                            handler.removeCallbacks(longPress);
                            if (rt4.MobileLayout.isChat(Math.round(downX / scale), Math.round(downY / scale))) {
                                state = State.CHAT;
                                chatAccum = 0;
                            } else if (rt4.MobileLayout.touchIsWorld(Math.round(downX / scale), Math.round(downY / scale))) {
                                state = State.ROTATE;
                                velYaw = velPitch = 0;
                                lastMoveMs = e.getEventTime();
                                rt4.CameraSmoother.stop();
                            } else {
                                GameEvents.press(downX, downY, shim.awt.event.MouseEvent.BUTTON1);
                                state = State.DRAGGING;
                                GameEvents.drag(x, y);
                            }
                        }
                    } else if (state == State.DRAGGING) {
                        GameEvents.drag(x, y);
                    } else if (state == State.CHAT) {
                        chatAccum += (y - lastY) / scale;
                        int steps = (int) (chatAccum / 14f);
                        if (steps != 0) {
                            chatAccum -= steps * 14f;
                            GameEvents.wheel(downX, downY, -steps);
                        }
                    } else if (state == State.ROTATE) {
                        double dyaw = -(x - lastX) / scale * 1.6;
                        double dpitch = (y - lastY) / scale * 1.0;
                        rt4.CameraSmoother.add(dyaw, dpitch);
                        long nowMs = e.getEventTime();
                        long span = Math.max(1L, nowMs - lastMoveMs);
                        // smoothed velocity in camera units per millisecond
                        velYaw = velYaw * 0.6 + (dyaw / span) * 0.4;
                        velPitch = velPitch * 0.6 + (dpitch / span) * 0.4;
                        lastMoveMs = nowMs;
                    }
                    lastX = x;
                    lastY = y;
                }
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                if (state == State.CAMERA) {
                    state = State.IGNORE; // wait until all fingers lift
                }
                return true;

            case MotionEvent.ACTION_UP:
                handler.removeCallbacks(longPress);
                if (state == State.ROTATE && e.getEventTime() - lastMoveMs < 60) {
                    rt4.CameraSmoother.fling(velYaw, velPitch);
                }
                if (state == State.PENDING) {
                    // Let the client see the cursor over the target for a few frames first, so
                    // it has built the right-click menu for that spot before the press arrives.
                    final float tx = downX, ty = downY;
                    if (rt4.MobileLayout.isChat(Math.round(tx / scale), Math.round(ty / scale))) {
                        Runnable r = GameEvents.onChatTap;
                        if (r != null) r.run();
                    }
                    long wait = Math.max(0L, 130L - (e.getEventTime() - e.getDownTime()));
                    handler.postDelayed(new Runnable() {
                        @Override public void run() {
                            GameEvents.move(tx, ty);
                            int lx = Math.round(tx / scale), ly = Math.round(ty / scale);
                            if (rt4.MobileLayout.touchIsWorld(lx, ly) && menuTopIsWalk()) {
                                probe(tx, ty, 0);
                            } else {
                                click(tx, ty);
                            }
                        }
                    }, wait);
                } else if (state == State.DRAGGING) {
                    GameEvents.release(e.getX(), e.getY(), shim.awt.event.MouseEvent.BUTTON1);
                }
                state = State.IDLE;
                return true;

            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                if (state == State.DRAGGING) {
                    GameEvents.release(lastX, lastY, shim.awt.event.MouseEvent.BUTTON1);
                }
                state = State.IDLE;
                return true;

            default:
                return true;
        }
    }

    private static float dist(MotionEvent e) {
        float dx = e.getX(0) - e.getX(1), dy = e.getY(0) - e.getY(1);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    // -------------------------------------------------------------- keyboard

    @Override
    public boolean onCheckIsTextEditor() { return true; }

    @Override
    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_FLAG_NO_FULLSCREEN | EditorInfo.IME_ACTION_NONE;
        return new BaseInputConnection(this, false) {
            private String composing = "";

            private void replaceComposing(String now) {
                int l = 0;
                int max = Math.min(composing.length(), now.length());
                while (l < max && composing.charAt(l) == now.charAt(l)) l++;
                for (int i = composing.length() - l; i > 0; i--) GameEvents.typeChar('\b');
                for (int i = l; i < now.length(); i++) GameEvents.typeChar(now.charAt(i));
                composing = now;
            }

            @Override public boolean commitText(CharSequence text, int newCursorPosition) {
                replaceComposing(text.toString());
                composing = "";
                return true;
            }
            @Override public boolean setComposingText(CharSequence text, int newCursorPosition) {
                replaceComposing(text.toString());
                return true;
            }
            @Override public boolean finishComposingText() {
                composing = "";
                return true;
            }
            @Override public boolean deleteSurroundingText(int beforeLength, int afterLength) {
                if (!composing.isEmpty()) {
                    replaceComposing(composing.substring(0, Math.max(0, composing.length() - Math.max(1, beforeLength))));
                } else {
                    for (int i = 0; i < Math.max(1, beforeLength); i++) GameEvents.typeChar('\b');
                }
                return true;
            }
            @Override public boolean sendKeyEvent(KeyEvent event) {
                return GameEvents.androidKey(event.getKeyCode(), event.getUnicodeChar(), event.getAction() == KeyEvent.ACTION_DOWN);
            }
            @Override public boolean performEditorAction(int actionCode) {
                GameEvents.typeChar('\n');
                return true;
            }
        };
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (GameEvents.androidKey(keyCode, event.getUnicodeChar(), true)) return true;
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (GameEvents.androidKey(keyCode, event.getUnicodeChar(), false)) return true;
        return super.onKeyUp(keyCode, event);
    }

    // ---------------------------------------------------------------- tap assist

    private static final int[][] PROBES = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};

    /** True when the client's top menu entry is just "Walk here" (nothing under the cursor). */
    private static boolean menuTopIsWalk() {
        try {
            int n = rt4.MiniMenu.size;
            return n <= 0 || rt4.MiniMenu.actions[n - 1] == rt4.MiniMenu.WALK_HERE;
        } catch (Throwable t) {
            return true;
        }
    }

    private static boolean menuHasTarget() {
        try {
            int n = rt4.MiniMenu.size;
            return n >= 2 && rt4.MiniMenu.actions[n - 1] != rt4.MiniMenu.WALK_HERE;
        } catch (Throwable t) {
            return false;
        }
    }

    private void click(final float x, final float y) {
        GameEvents.press(x, y, shim.awt.event.MouseEvent.BUTTON1);
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                GameEvents.release(x, y, shim.awt.event.MouseEvent.BUTTON1);
            }
        }, 90L);
    }

    /** Run {@code r} after the client has drawn at least two more frames (or 160 ms passed). */
    private void afterFrames(final Runnable r) {
        final int f0 = rt4.SavedAccount.frames;
        final long end = System.currentTimeMillis() + 160L;
        handler.post(new Runnable() {
            @Override public void run() {
                if (rt4.SavedAccount.frames >= f0 + 2 || System.currentTimeMillis() >= end) {
                    r.run();
                } else {
                    handler.postDelayed(this, 8L);
                }
            }
        });
    }

    /** Nothing was under the finger: try a few spots just around it so small targets are easy to hit. */
    private void probe(final float tx, final float ty, final int i) {
        if (i >= PROBES.length) {
            GameEvents.move(tx, ty);
            afterFrames(new Runnable() {
                @Override public void run() { click(tx, ty); }
            });
            return;
        }
        final float px = tx + PROBES[i][0] * 11f * scale;
        final float py = ty + PROBES[i][1] * 11f * scale;
        GameEvents.move(px, py);
        afterFrames(new Runnable() {
            @Override public void run() {
                if (menuHasTarget()) {
                    click(px, py);
                } else {
                    probe(tx, ty, i + 1);
                }
            }
        });
    }
}
