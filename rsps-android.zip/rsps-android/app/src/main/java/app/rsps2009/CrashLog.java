package app.rsps2009;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Saves the last uncaught exception to a file so the launcher can show it next start. */
final class CrashLog {
    private static boolean installed;

    private CrashLog() {}

    static File file(Context c) { return new File(c.getFilesDir(), "crash.txt"); }

    static synchronized void install(Context c) {
        if (installed) return;
        installed = true;
        final File f = file(c.getApplicationContext());
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                write(f, "Thread: " + t.getName() + "\n" + trace(e));
                if (old != null) old.uncaughtException(t, e);
            }
        });
    }

    static void crumb(Context c, String text) {
        try (FileOutputStream o = new FileOutputStream(file(c), true)) {
            o.write((new java.text.SimpleDateFormat("HH:mm:ss.SSS").format(new java.util.Date()) + " " + text + "\n").getBytes("UTF-8"));
        } catch (Throwable ignored) {
        }
    }

    static void write(File f, String text) {
        try (FileOutputStream o = new FileOutputStream(f, false)) {
            o.write(text.getBytes("UTF-8"));
        } catch (Throwable ignored) {
        }
    }

    static String trace(Throwable e) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        String s = sw.toString();
        return s.length() > 6000 ? s.substring(0, 6000) : s;
    }

    static String read(Context c) {
        File f = file(c);
        if (!f.exists()) return null;
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            byte[] b = new byte[(int) Math.min(f.length(), 8000)];
            int n = in.read(b);
            String s = new String(b, 0, Math.max(n, 0), "UTF-8");
            return s.trim().isEmpty() ? null : s;
        } catch (Throwable e) {
            return null;
        }
    }
}
