package app.rsps2009;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

/** Small settings store + writer for the client's config.json. */
final class Settings {
    static final String PREFS = "rsps2009";
    static final String DEFAULT_HOST = "144.202.35.127";

    final String host;
    final int serverPort;
    final int worldListPort;
    final int js5Port;
    final int world;
    final float renderScale;
    final boolean portrait;

    Settings(SharedPreferences p) {
        host = p.getString("host", DEFAULT_HOST);
        serverPort = p.getInt("serverPort", 43594);
        worldListPort = p.getInt("wlPort", 43595);
        js5Port = p.getInt("js5Port", 43595);
        world = p.getInt("world", 1);
        renderScale = p.getFloat("scale2", 2.5f);
        portrait = p.getBoolean("portrait", false);
    }

    static Settings load(Context c) {
        return new Settings(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE));
    }

    /** Writes the config.json the client reads (same keys as the desktop client). */
    File writeClientConfig(Context c) throws Exception {
        File f = new File(c.getFilesDir(), "config.json");
        String json = "{\n"
                + "  \"ip_management\": \"" + esc(host) + "\",\n"
                + "  \"ip_address\": \"" + esc(host) + "\",\n"
                + "  \"world\": " + world + ",\n"
                + "  \"server_port\": " + serverPort + ",\n"
                + "  \"wl_port\": " + worldListPort + ",\n"
                + "  \"js5_port\": " + js5Port + ",\n"
                + "  \"mouseWheelZoom\": true,\n"
                + "  \"pluginsFolder\": \"plugins\"\n"
                + "}\n";
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8")) {
            w.write(json);
        }
        return f;
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
