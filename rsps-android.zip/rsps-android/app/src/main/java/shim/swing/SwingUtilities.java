package shim.swing;

import shim.awt.event.MouseEvent;

public final class SwingUtilities {
    private SwingUtilities() {}
    public static boolean isLeftMouseButton(MouseEvent e) { return e.getButton() == MouseEvent.BUTTON1; }
    public static boolean isMiddleMouseButton(MouseEvent e) { return e.getButton() == MouseEvent.BUTTON2; }
    public static boolean isRightMouseButton(MouseEvent e) { return e.getButton() == MouseEvent.BUTTON3; }
}
