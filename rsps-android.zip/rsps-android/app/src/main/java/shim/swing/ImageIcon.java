package shim.swing;

import java.net.URL;
import shim.awt.Image;
import shim.awt.image.BufferedImage;

public class ImageIcon {
    public ImageIcon(URL url) {}
    public Image getImage() { return new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB); }
}
