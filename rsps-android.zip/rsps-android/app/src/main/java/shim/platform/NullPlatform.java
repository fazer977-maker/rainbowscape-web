package shim.platform;

/** Headless host used for tests and before the real platform is installed. */
public class NullPlatform implements Platform {
    public volatile int frames;
    public volatile int width = 765, height = 503;
    @Override public void present(int[] pixels, int w, int h, int cx, int cy, int cw, int ch) { frames++; }
    @Override public int viewWidth() { return width; }
    @Override public int viewHeight() { return height; }
    @Override public float renderScale() { return 1f; }
    @Override public void setTitle(String title) {}
    @Override public int[] textMetrics(String font, int style, int size) { return new int[] { size * 4 / 5, size / 5, 0 }; }
    @Override public int textWidth(String text, String font, int style, int size) { return text.length() * size * 6 / 10; }
    @Override public void drawText(int[] dst, int dw, int dh, String text, int x, int y, String font, int style, int size, int argb) {}
    @Override public AudioOut openAudio(int sampleRate, int channels, int bufferBytes) {
        return new AudioOut() {
            @Override public int write(byte[] d, int o, int l) { return l; }
            @Override public int available() { return bufferBytes; }
            @Override public void flush() {}
            @Override public void close() {}
        };
    }
    @Override public String dataDir() { return System.getProperty("java.io.tmpdir"); }
}
