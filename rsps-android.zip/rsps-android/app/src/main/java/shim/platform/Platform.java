package shim.platform;

/** Everything the AWT replacement needs from the host (Android, or a headless test host). */
public interface Platform {
    /** Show a finished frame. {@code pixels} is w*h ARGB (alpha ignored). Clip is the dirty rectangle. */
    void present(int[] pixels, int w, int h, int clipX, int clipY, int clipW, int clipH);
    /** Pixel size of the area the game may use (physical px). */
    int viewWidth();
    int viewHeight();
    /** Physical pixels per logical pixel the game should render at (>=1). */
    float renderScale();
    void setTitle(String title);
    /** {ascent, descent, leading}. */
    int[] textMetrics(String font, int style, int size);
    int textWidth(String text, String font, int style, int size);
    /** Draw antialiased text into an ARGB buffer; y is the baseline. */
    void drawText(int[] dst, int dw, int dh, String text, int x, int y, String font, int style, int size, int argb);
    /** Open a 16-bit PCM output. */
    AudioOut openAudio(int sampleRate, int channels, int bufferBytes);
    /** Directory the game may write its cache to (ends without trailing slash). */
    String dataDir();

    interface AudioOut {
        int write(byte[] data, int off, int len);
        int available();
        void flush();
        void close();
    }
}
