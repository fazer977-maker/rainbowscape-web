package shim.imageio;

import java.io.File;
import shim.awt.image.BufferedImage;

public final class ImageIO {
    private ImageIO() {}
    public static boolean write(BufferedImage image, String format, File out) { return false; }
}
