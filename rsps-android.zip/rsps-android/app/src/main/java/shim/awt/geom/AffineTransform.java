package shim.awt.geom;

public class AffineTransform {
    public double getScaleX() { return 1.0; }
    public double getScaleY() { return 1.0; }
}
