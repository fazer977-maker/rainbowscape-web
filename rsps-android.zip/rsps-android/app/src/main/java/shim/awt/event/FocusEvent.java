package shim.awt.event;

import shim.awt.AWTEvent;

public class FocusEvent extends AWTEvent {
    public static final int FOCUS_GAINED = 1004, FOCUS_LOST = 1005;
    public FocusEvent(Object source, int id) { super(source, id); }
}
