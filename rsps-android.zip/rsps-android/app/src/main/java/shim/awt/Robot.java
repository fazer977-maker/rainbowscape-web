package shim.awt;

import shim.awt.image.BufferedImage;

public class Robot {
    public Robot() {}
    public Robot(GraphicsDevice d) {}
    public void mouseMove(int x, int y) {}
    public BufferedImage createScreenCapture(Rectangle r) { return new BufferedImage(Math.max(1, r.width), Math.max(1, r.height), BufferedImage.TYPE_INT_RGB); }
}
