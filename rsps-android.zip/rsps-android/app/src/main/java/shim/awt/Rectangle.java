package shim.awt;

public class Rectangle implements Shape {
    public int x, y, width, height;
    public Rectangle() {}
    public Rectangle(int x, int y, int w, int h) { this.x = x; this.y = y; width = w; height = h; }
    public Rectangle(int w, int h) { this(0, 0, w, h); }
    @Override public Rectangle getBounds() { return new Rectangle(x, y, width, height); }
    public Rectangle intersection(Rectangle r) {
        int x1 = Math.max(x, r.x), y1 = Math.max(y, r.y);
        int x2 = Math.min(x + width, r.x + r.width), y2 = Math.min(y + height, r.y + r.height);
        return new Rectangle(x1, y1, Math.max(0, x2 - x1), Math.max(0, y2 - y1));
    }
    public boolean isEmpty() { return width <= 0 || height <= 0; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}
