package shim.awt;

import shim.awt.geom.AffineTransform;

public class GraphicsConfiguration {
    private final GraphicsDevice device;
    public GraphicsConfiguration(GraphicsDevice device) { this.device = device; }
    public GraphicsDevice getDevice() { return device; }
    public AffineTransform getDefaultTransform() { return new AffineTransform(); }
}
