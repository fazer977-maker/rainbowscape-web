package shim.awt.event;

public interface FocusListener {
    void focusGained(FocusEvent e);
    void focusLost(FocusEvent e);
}
