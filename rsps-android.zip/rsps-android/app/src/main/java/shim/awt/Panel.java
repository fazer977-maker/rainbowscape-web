package shim.awt;

public class Panel extends Container {
}
