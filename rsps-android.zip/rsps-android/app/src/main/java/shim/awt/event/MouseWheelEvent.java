package shim.awt.event;

public class MouseWheelEvent extends MouseEvent {
    public static final int WHEEL_UNIT_SCROLL = 0;
    private final int rotation;
    public MouseWheelEvent(Object source, long when, int modifiers, int x, int y, int rotation) {
        super(source, MOUSE_WHEEL, when, modifiers, x, y, 0, false);
        this.rotation = rotation;
    }
    public int getWheelRotation() { return rotation; }
    public double getPreciseWheelRotation() { return rotation; }
    public int getScrollAmount() { return 3; }
    public int getScrollType() { return WHEEL_UNIT_SCROLL; }
    public int getUnitsToScroll() { return rotation * 3; }
}
