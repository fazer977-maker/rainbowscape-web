package shim.awt.event;

public interface MouseWheelListener {
    void mouseWheelMoved(MouseWheelEvent e);
}
