package shim.awt.image;

public class DirectColorModel extends ColorModel {
    public DirectColorModel(int bits, int rmask, int gmask, int bmask) {}
    @Override public int getRGB(int pixel) { return pixel | 0xFF000000; }
}
