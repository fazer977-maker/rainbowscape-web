package shim.awt.image;

import shim.awt.Graphics;
import shim.awt.Image;
import shim.awt.BufferGraphics;

/** ARGB int[] image. {@code data} is shared with the creator when one is supplied. */
public class BufferedImage extends Image {
    public static final int TYPE_INT_RGB = 1, TYPE_INT_ARGB = 2, TYPE_INT_ARGB_PRE = 3;
    public final int[] data;
    private final int w, h, type;

    public BufferedImage(int w, int h, int type) {
        this(w, h, type, new int[Math.max(1, w * h)]);
    }
    public BufferedImage(int w, int h, int type, int[] data) {
        this.w = w; this.h = h; this.type = type; this.data = data;
    }
    public int getWidth() { return w; }
    public int getHeight() { return h; }
    public int getType() { return type; }
    @Override public int getWidth(ImageObserver o) { return w; }
    @Override public int getHeight(ImageObserver o) { return h; }
    public int getRGB(int x, int y) { return data[y * w + x]; }
    public void setRGB(int x, int y, int rgb) { data[y * w + x] = rgb; }
    public void setRGB(int startX, int startY, int rw, int rh, int[] rgbArray, int offset, int scansize) {
        for (int y = 0; y < rh; y++) {
            System.arraycopy(rgbArray, offset + y * scansize, data, (startY + y) * w + startX, rw);
        }
    }
    public int[] getRGB(int startX, int startY, int rw, int rh, int[] out, int offset, int scansize) {
        if (out == null) out = new int[offset + rh * scansize];
        for (int y = 0; y < rh; y++) {
            System.arraycopy(data, (startY + y) * w + startX, out, offset + y * scansize, rw);
        }
        return out;
    }
    @Override public Graphics getGraphics() { return createGraphics(); }
    public Graphics createGraphics() { return new BufferGraphics(this, null); }
}
