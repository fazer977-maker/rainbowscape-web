package shim.awt;

import shim.platform.Platforms;

public class FontMetrics {
    private final Font font;
    private final int[] m;
    public FontMetrics(Font font) {
        this.font = font;
        this.m = Platforms.current.textMetrics(font.getName(), font.getStyle(), font.getSize());
    }
    public Font getFont() { return font; }
    public int stringWidth(String s) { return Platforms.current.textWidth(s, font.getName(), font.getStyle(), font.getSize()); }
    public int charWidth(char c) { return stringWidth(String.valueOf(c)); }
    public int getAscent() { return m[0]; }
    public int getDescent() { return m[1]; }
    public int getLeading() { return m[2]; }
    public int getMaxAscent() { return m[0]; }
    public int getMaxDescent() { return m[1]; }
    public int getHeight() { return m[0] + m[1] + m[2]; }
}
