package shim.awt;

import shim.awt.image.ImageObserver;

public abstract class Image {
    public abstract int getWidth(ImageObserver observer);
    public abstract int getHeight(ImageObserver observer);
    public abstract Graphics getGraphics();
    public void flush() {}
}
