package shim.awt;

import shim.platform.Platforms;

public class Toolkit {
    private static final Toolkit INSTANCE = new Toolkit();
    private final EventQueue queue = new EventQueue();
    public static Toolkit getDefaultToolkit() { return INSTANCE; }
    public EventQueue getSystemEventQueue() { return queue; }
    public Cursor createCustomCursor(Image image, Point hotSpot, String name) { return new Cursor(Cursor.DEFAULT_CURSOR); }
    public Dimension getScreenSize() { return new Dimension(Platforms.current.viewWidth(), Platforms.current.viewHeight()); }
    public void beep() {}
    public void sync() {}
}
