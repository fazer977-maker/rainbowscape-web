package shim.awt;

import shim.awt.image.BufferedImage;
import shim.platform.Platforms;

public class Canvas extends Component {
    private BufferedImage backing;
    private Rectangle dirty;

    @Override public synchronized void setSize(int w, int h) {
        super.setSize(w, h);
        if (w > 0 && h > 0 && (backing == null || backing.getWidth() != w || backing.getHeight() != h)) {
            backing = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
            dirty = null;
        }
    }

    @Override public synchronized Graphics getGraphics() {
        if (backing == null) {
            if (width <= 0 || height <= 0) return null;
            setSize(width, height);
        }
        return new BufferGraphics(backing, this);
    }

    synchronized void markDirty(Rectangle r) {
        dirty = dirty == null ? r : union(dirty, r);
    }

    synchronized void flushDirty() {
        if (dirty == null || backing == null) return;
        Rectangle r = dirty.intersection(new Rectangle(0, 0, backing.getWidth(), backing.getHeight()));
        dirty = null;
        if (!r.isEmpty()) {
            Platforms.current.present(backing.data, backing.getWidth(), backing.getHeight(), r.x, r.y, r.width, r.height);
        }
    }

    private static Rectangle union(Rectangle a, Rectangle b) {
        int x1 = Math.min(a.x, b.x), y1 = Math.min(a.y, b.y);
        int x2 = Math.max(a.x + a.width, b.x + b.width), y2 = Math.max(a.y + a.height, b.y + b.height);
        return new Rectangle(x1, y1, x2 - x1, y2 - y1);
    }
}
