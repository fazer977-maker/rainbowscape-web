package shim.awt;

public class EventQueue {
    public AWTEvent peekEvent() { return null; }
    public void postEvent(AWTEvent e) {}
}
