package shim.sound.sampled;

public interface Line {
    class Info {
        protected final Class<?> lineClass;
        public Info(Class<?> lineClass) { this.lineClass = lineClass; }
    }
}
