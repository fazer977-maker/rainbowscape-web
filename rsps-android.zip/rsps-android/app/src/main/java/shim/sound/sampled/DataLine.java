package shim.sound.sampled;

public interface DataLine extends Line {
    class Info extends Line.Info {
        private final AudioFormat format;
        private final int bufferSize;
        public Info(Class<?> lineClass, AudioFormat format, int bufferSize) {
            super(lineClass);
            this.format = format;
            this.bufferSize = bufferSize;
        }
        public AudioFormat getFormat() { return format; }
        public int getBufferSize() { return bufferSize; }
    }
}
