package shim.sound.sampled;

public class LineUnavailableException extends Exception {
    public LineUnavailableException() {}
    public LineUnavailableException(String m) { super(m); }
}
