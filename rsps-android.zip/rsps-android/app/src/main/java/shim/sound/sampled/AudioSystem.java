package shim.sound.sampled;

public final class AudioSystem {
    private AudioSystem() {}
    public static Mixer.Info[] getMixerInfo() { return new Mixer.Info[] { new Mixer.Info("Android") }; }
    public static Line getLine(Line.Info info) throws LineUnavailableException {
        DataLine.Info di = (DataLine.Info) info;
        return new SourceDataLine(di.getFormat(), di.getBufferSize());
    }
}
