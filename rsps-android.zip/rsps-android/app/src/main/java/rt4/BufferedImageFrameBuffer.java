package rt4;

import shim.awt.Component;
import shim.awt.Graphics;
import shim.awt.Shape;
import shim.awt.image.BufferedImage;

public final class BufferedImageFrameBuffer extends FrameBuffer {

	private Component component;

	@Override
	public final void draw(Graphics graphics) {
		graphics.drawImage(this.image, 0, 0, null);
	}

	@Override
	public final void init(int height, int width, Component component) {
		this.pixels = new int[width * height + 1];
		this.height = height;
		this.width = width;
		this.image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB, this.pixels);
		this.component = component;
		this.makeTarget();
	}

	@Override
	public final void drawAt(int width, int x, int height, Graphics graphics, int y) {
		Shape clip = graphics.getClip();
		graphics.clipRect(x, y, width, height);
		graphics.drawImage(this.image, 0, 0, null);
		graphics.setClip(clip);
	}
}
