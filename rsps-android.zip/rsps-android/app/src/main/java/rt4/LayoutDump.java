package rt4;

import shim.platform.Platforms;

/** Diagnostic: lists where the top-level interface puts things, so a mobile layout can be built. */
public final class LayoutDump {
    private static int frames;
    private static boolean done;
    public static volatile String last;

    private LayoutDump() {}

    /** Call once per frame. Dumps ~20s after login. */
    public static void tick() {
        if (done) return;
        if (client.gameState != 30 || InterfaceList.topLevelInterface == -1) { frames = 0; return; }
        if (++frames < 1000) return;
        done = true;
        try {
            StringBuilder b = new StringBuilder();
            b.append("canvas ").append(GameShell.canvasWidth).append('x').append(GameShell.canvasHeight).append('\n');
            int top = InterfaceList.topLevelInterface;
            b.append("toplevel ").append(top).append('\n');
            Component[][] comps = InterfaceList.components;
            if (comps != null && top >= 0 && top < comps.length && comps[top] != null) {
                for (int j = 0; j < comps[top].length; j++) {
                    Component c = comps[top][j];
                    if (c == null) continue;
                    b.append(j).append(" t").append(c.type)
                     .append(" @").append(c.x).append(',').append(c.y)
                     .append(' ').append(c.width).append('x').append(c.height)
                     .append(" par").append(c.overlayer);
                    if (c.hidden) b.append(" H");
                    if (c.spriteId != -1) b.append(" spr").append(c.spriteId);
                    if (c.clientCode != 0) b.append(" cc").append(c.clientCode);
                    b.append('\n');
                }
            }
            b.append("-- open sub-interfaces (attach component -> interface) --\n");
            for (ComponentPointer p = (ComponentPointer) InterfaceList.openInterfaces.head(); p != null; p = (ComponentPointer) InterfaceList.openInterfaces.next()) {
                b.append(p.key >> 16).append(':').append(p.key & 0xFFFF).append(" -> ").append(p.interfaceId).append(" type").append(p.type);
                int id = p.interfaceId;
                if (comps != null && id >= 0 && id < comps.length && comps[id] != null && comps[id].length > 0 && comps[id][0] != null) {
                    Component c = comps[id][0];
                    b.append(" root0 ").append(c.width).append('x').append(c.height);
                }
                b.append('\n');
            }
            last = b.toString();
            Platforms.error("LAYOUT DUMP (" + last.length() + " chars)", null);
            Platforms.dump(last);
        } catch (Throwable t) {
            Platforms.error("layout dump failed", t);
        }
    }
}
