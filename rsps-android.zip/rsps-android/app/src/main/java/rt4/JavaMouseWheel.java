package rt4;

import org.openrs2.deob.annotation.OriginalArg;
import org.openrs2.deob.annotation.OriginalClass;
import org.openrs2.deob.annotation.OriginalMember;
import org.openrs2.deob.annotation.Pc;

import shim.awt.Component;
import shim.awt.event.MouseWheelEvent;
import shim.awt.event.MouseWheelListener;

import static rt4.MathUtils.clamp;

@OriginalClass("client!o")
public final class JavaMouseWheel extends MouseWheel implements MouseWheelListener {

	@OriginalMember(owner = "client!o", name = "g", descriptor = "I")
	public int currentRotation = 0;
	public int previousRotation = 0;

	@OriginalMember(owner = "client!o", name = "a", descriptor = "(ZLjava/awt/Component;)V")
	@Override
	public final void stop(@OriginalArg(1) Component component) {
		component.removeMouseWheelListener(this);
	}

	@OriginalMember(owner = "client!o", name = "a", descriptor = "(I)I")
	@Override
	public final synchronized int getRotation() {
		@Pc(2) int rotation = this.currentRotation;
		this.currentRotation = 0;
		return rotation;
	}

	@OriginalMember(owner = "client!o", name = "mouseWheelMoved", descriptor = "(Ljava/awt/event/MouseWheelEvent;)V")
	@Override
	public final synchronized void mouseWheelMoved(@OriginalArg(0) MouseWheelEvent event) {
		this.previousRotation = this.currentRotation;
		this.currentRotation += event.getWheelRotation();
	}

	@OriginalMember(owner = "client!o", name = "a", descriptor = "(Ljava/awt/Component;I)V")
	@Override
	public final void start(@OriginalArg(0) Component component) {
		component.addMouseWheelListener(this);
	}
}
