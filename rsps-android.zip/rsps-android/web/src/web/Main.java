package web;

import rt4.GameShell;
import shim.awt.Canvas;
import shim.awt.event.FocusEvent;
import shim.awt.event.KeyEvent;
import shim.awt.event.MouseEvent;
import shim.awt.event.MouseWheelEvent;
import shim.platform.Platforms;

/** Entry point of the browser build: installs the web platform, starts the client, pumps input. */
public final class Main {
	private Main() {}

	public static void main(String[] args) {
		Platforms.current = new WebPlatform();
		Platforms.sink = new Platforms.Sink() {
			@Override public void log(String text) { Js.log(text); }
		};
		rt4.DisplayMode.resizableSD = true;

		Thread game = new Thread(new Runnable() {
			@Override public void run() {
				try {
					rt4.client.main(new String[] { "--config", "web" });
				} catch (Throwable t) {
					Js.log("client crashed: " + t);
				}
			}
		}, "rs-main");
		game.start();

		Thread input = new Thread(new Runnable() {
			@Override public void run() {
				while (true) {
					try {
						while (Js.inHas() != 0) {
							int kind = Js.inNext(), a = Js.inNext(), b = Js.inNext(), c = Js.inNext();
							dispatch(kind, a, b, c);
						}
						Thread.sleep(6);
					} catch (Throwable t) {
						Js.log("input error: " + t);
					}
				}
			}
		}, "rs-input");
		input.setDaemon(true);
		input.start();
	}

	// ---- event kinds, produced by index.html: 1 move, 2 press, 3 release, 4 drag, 5 wheel,
	// 6 typed char, 7 control key, 8 navigation key, 9 focus

	private static int dragMode, dragLastX, dragLastY, dragStartX, dragStartY;
	private static float chatAccum;

	private static void dispatch(int kind, int a, int b, int c) {
		Canvas cv = GameShell.canvas;
		if (cv == null) return;
		long now = System.currentTimeMillis();
		switch (kind) {
			case 1:
				cv.processMouseMotionEvent(new MouseEvent(cv, MouseEvent.MOUSE_MOVED, now, 0, a - cv.getX(), b - cv.getY(), 0, false));
				break;
			case 4:
				cv.processMouseMotionEvent(new MouseEvent(cv, MouseEvent.MOUSE_DRAGGED, now, MouseEvent.BUTTON1_DOWN_MASK, a - cv.getX(), b - cv.getY(), 0, false));
				break;
			case 2:
				cv.processMouseEvent(new MouseEvent(cv, MouseEvent.MOUSE_PRESSED, now, mods(c), a - cv.getX(), b - cv.getY(), 1, false, c));
				break;
			case 3:
				cv.processMouseEvent(new MouseEvent(cv, MouseEvent.MOUSE_RELEASED, now, 0, a - cv.getX(), b - cv.getY(), 1, false, c));
				break;
			case 5:
				if (c != 0) cv.processMouseWheelEvent(new MouseWheelEvent(cv, now, 0, a - cv.getX(), b - cv.getY(), c));
				break;
			case 6:
				typeChar(cv, (char) a);
				break;
			case 7:
				controlKey(cv, a, (char) b);
				break;
			case 8:
				key(cv, KeyEvent.KEY_PRESSED, a, KeyEvent.CHAR_UNDEFINED);
				key(cv, KeyEvent.KEY_RELEASED, a, KeyEvent.CHAR_UNDEFINED);
				break;
			case 10:
				rt4.CameraSmoother.add(a / 100.0, b / 100.0);
				break;
			case 11:
				if (a > 0) rt4.Camera.ZOOM = Math.max(250, Math.min(1600, Math.round(rt4.Camera.ZOOM * (a / 1000.0f))));
				break;
			case 12:
				dragLastX = a; dragLastY = b; dragStartX = a; dragStartY = b; chatAccum = 0;
				if (rt4.MobileLayout.isChat(a, b)) {
					dragMode = 3;
				} else if (rt4.MobileLayout.touchIsWorld(a, b)) {
					dragMode = 2;
					rt4.CameraSmoother.stop();
				} else {
					dragMode = 1;
					dispatch(2, a, b, MouseEvent.BUTTON1);
					dispatch(4, a, b, 0);
				}
				break;
			case 14:
				if (dragMode == 2) {
					rt4.CameraSmoother.add(-(a - dragLastX) * 1.6, (b - dragLastY) * 1.0);
				} else if (dragMode == 3) {
					chatAccum += (b - dragLastY);
					int steps = (int) (chatAccum / 14f);
					if (steps != 0) { chatAccum -= steps * 14f; dispatch(5, dragStartX, dragStartY, -steps); }
				} else if (dragMode == 1) {
					dispatch(4, a, b, 0);
				}
				dragLastX = a; dragLastY = b;
				break;
			case 13:
				if (dragMode == 1) dispatch(3, a, b, MouseEvent.BUTTON1);
				dragMode = 0;
				break;
			case 9:
				cv.processFocusEvent(new FocusEvent(cv, a != 0 ? FocusEvent.FOCUS_GAINED : FocusEvent.FOCUS_LOST));
				break;
			default:
				break;
		}
	}

	private static int mods(int button) {
		if (button == MouseEvent.BUTTON3) return MouseEvent.BUTTON3_DOWN_MASK | MouseEvent.BUTTON3_MASK;
		return MouseEvent.BUTTON1_DOWN_MASK | MouseEvent.BUTTON1_MASK;
	}

	private static void key(Canvas cv, int id, int vk, char ch) {
		cv.processKeyEvent(new KeyEvent(cv, id, System.currentTimeMillis(), 0, vk, ch));
	}

	private static void controlKey(Canvas cv, int vk, char ch) {
		key(cv, KeyEvent.KEY_PRESSED, vk, ch);
		key(cv, KeyEvent.KEY_TYPED, 0, ch);
		key(cv, KeyEvent.KEY_RELEASED, vk, ch);
	}

	private static void typeChar(Canvas cv, char ch) {
		if (ch == '\n' || ch == '\r') { controlKey(cv, KeyEvent.VK_ENTER, '\n'); return; }
		if (ch == '\b') { controlKey(cv, KeyEvent.VK_BACK_SPACE, '\b'); return; }
		if (ch == '\t') { controlKey(cv, KeyEvent.VK_TAB, '\t'); return; }
		int vk = KeyEvent.VK_UNDEFINED;
		if (ch >= 'a' && ch <= 'z') vk = KeyEvent.VK_A + (ch - 'a');
		else if (ch >= 'A' && ch <= 'Z') vk = KeyEvent.VK_A + (ch - 'A');
		else if (ch >= '0' && ch <= '9') vk = KeyEvent.VK_0 + (ch - '0');
		else if (ch == ' ') vk = KeyEvent.VK_SPACE;
		key(cv, KeyEvent.KEY_PRESSED, vk, ch);
		key(cv, KeyEvent.KEY_TYPED, 0, ch);
		key(cv, KeyEvent.KEY_RELEASED, vk, ch);
	}
}
