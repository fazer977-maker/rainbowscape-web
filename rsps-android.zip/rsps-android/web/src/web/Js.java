package web;

import org.teavm.jso.JSBody;
import org.teavm.jso.JSObject;

/**
 * Everything the game needs from the page. The matching JavaScript lives in static/index.html
 * (window.rs). Java arrays reach JavaScript as wrapper objects whose .data is the typed array.
 */
public final class Js {
	private Js() {}

	@JSBody(params = { "key" }, script = "return String(window.rs.cfg(key));")
	public static native String cfgStr(String key);

	@JSBody(params = { "key" }, script = "return window.rs.cfg(key) | 0;")
	public static native int cfgInt(String key);

	@JSBody(params = { "url" }, script = "return window.rs.wsOpen(url);")
	public static native JSObject wsOpen(String url);

	@JSBody(params = { "ws" }, script = "return ws.state;")
	public static native int wsState(JSObject ws);

	@JSBody(params = { "ws" }, script = "return ws.avail();")
	public static native int wsAvail(JSObject ws);

	@JSBody(params = { "f" }, script = "return window.rs.cacheLen(f);")
	public static native int cacheLen(String f);

	@JSBody(params = { "f", "p" }, script = "return window.rs.cacheHas(f, p);")
	public static native int cacheHas(String f, int p);

	@JSBody(params = { "f", "p", "i" }, script = "return window.rs.cacheGet4(f, p, i);")
	public static native int cacheGet4(String f, int p, int i);

	@JSBody(params = { "f", "p" }, script = "window.rs.cacheDrop(f, p);")
	public static native void cacheDrop(String f, int p);

	@JSBody(params = { "f", "p", "a", "n" }, script = "window.rs.cachePut(f, p, (a.data || a), n);")
	public static native void cachePut(String f, int p, byte[] a, int n);

	@JSBody(params = { "f", "n" }, script = "window.rs.cacheMeta(f, n);")
	public static native void cacheMeta(String f, int n);

	@JSBody(params = { "ws", "len" }, script = "return ws.readStr(len);")
	public static native String wsReadStr(JSObject ws, int len);

	@JSBody(params = { "f", "p" }, script = "return window.rs.cacheGetStr(f, p);")
	public static native String cacheGetStr(String f, int p);

	@JSBody(params = { "ws", "len" }, script = "return ws.readTmp(len);")
	public static native int wsReadTmp(JSObject ws, int len);

	@JSBody(params = { "ws", "i" }, script = "return ws.tmp4(i);")
	public static native int wsTmp4(JSObject ws, int i);

	@JSBody(params = { "style", "size", "k" }, script = "return window.rs.metric(style, size, k);")
	public static native int metric(int style, int size, int k);

	@JSBody(params = { "text", "style", "size", "tw", "th", "ascent" }, script = "window.rs.glyphs(text, style, size, tw, th, ascent);")
	public static native void glyphsMake(String text, int style, int size, int tw, int th, int ascent);

	@JSBody(params = { "i" }, script = "return window.rs.glyphAt(i);")
	public static native int glyphAt(int i);

	@JSBody(params = { "ws", "dst", "off", "len" }, script = "return ws.read((dst.data || dst), off, len);")
	public static native int wsRead(JSObject ws, byte[] dst, int off, int len);

	@JSBody(params = { "ws", "src", "off", "len" }, script = "ws.send((src.data || src), off, len);")
	public static native void wsSend(JSObject ws, byte[] src, int off, int len);

	@JSBody(params = { "ws" }, script = "ws.close();")
	public static native void wsClose(JSObject ws);

	@JSBody(params = { "px", "w", "h", "cx", "cy", "cw", "ch" }, script = "window.rs.present((px.data || px), w, h, cx, cy, cw, ch);")
	public static native void present(int[] px, int w, int h, int cx, int cy, int cw, int ch);

	@JSBody(params = {}, script = "return window.rs.viewW();")
	public static native int viewW();

	@JSBody(params = {}, script = "return window.rs.viewH();")
	public static native int viewH();

	@JSBody(params = { "font", "style", "size", "out" }, script = "window.rs.textMetrics(style, size, (out.data || out));")
	public static native void textMetrics(String font, int style, int size, int[] out);

	@JSBody(params = { "text", "style", "size" }, script = "return window.rs.textWidth(text, style, size);")
	public static native int textWidth(String text, int style, int size);

	@JSBody(params = { "text", "style", "size", "tw", "th", "ascent", "alpha" }, script = "window.rs.glyphs(text, style, size, tw, th, ascent, (alpha.data || alpha));")
	public static native void glyphs(String text, int style, int size, int tw, int th, int ascent, int[] alpha);

	@JSBody(params = {}, script = "return window.rs.inHas() ? 1 : 0;")
	public static native int inHas();

	@JSBody(params = {}, script = "return window.rs.inNext() | 0;")
	public static native int inNext();

	@JSBody(params = { "text" }, script = "window.rs.log(String(text));")
	public static native void log(String text);

	@JSBody(params = { "url" }, script = "window.open(url, '_blank');")
	public static native void openUrl(String url);

	@JSBody(params = { "title" }, script = "document.title = title;")
	public static native void setTitle(String title);

	@JSBody(params = { "n", "rate" }, script = "window.rs.audioFeed && window.rs.audioFeed(n, rate);")
	public static native void audioTick(int n, int rate);
}
