package web;

import shim.platform.Platform;

/** Browser implementation of the platform layer: a canvas for pixels, canvas 2D for text. */
public final class WebPlatform implements Platform {

	@Override
	public void present(int[] pixels, int w, int h, int cx, int cy, int cw, int ch) {
		if (w <= 0 || h <= 0) {
			return;
		}
		Js.present(pixels, w, h, cx, cy, cw, ch);
	}

	@Override public int viewWidth() { return Math.max(1, Js.viewW()); }
	@Override public int viewHeight() { return Math.max(1, Js.viewH()); }
	@Override public float renderScale() { return 1f; }
	@Override public void setTitle(String title) { Js.setTitle(title); }

	private final int[] metrics = new int[3];

	@Override
	public synchronized int[] textMetrics(String font, int style, int size) {
		return new int[] { Js.metric(style, size, 0), Js.metric(style, size, 1), Js.metric(style, size, 2) };
	}

	@Override
	public int textWidth(String text, String font, int style, int size) {
		return Js.textWidth(text, style, size);
	}

	private int[] alpha = new int[0];

	@Override
	public synchronized void drawText(int[] dst, int dw, int dh, String text, int x, int y, String font, int style, int size, int argb) {
		int[] m = textMetrics(font, style, size);
		int ascent = m[0], descent = m[1];
		int tw = Js.textWidth(text, style, size) + 2;
		int th = ascent + descent + 2;
		if (tw <= 2 || th <= 0 || tw > 4096) {
			return;
		}
		if (alpha.length < tw * th) {
			alpha = new int[tw * th];
		}
		Js.glyphsMake(text, style, size, tw, th, ascent + 1);
		int total = tw * th;
		for (int i = 0; i < total; i += 4) {
			int v = Js.glyphAt(i);
			alpha[i] = v & 255;
			if (i + 1 < total) alpha[i + 1] = (v >> 8) & 255;
			if (i + 2 < total) alpha[i + 2] = (v >> 16) & 255;
			if (i + 3 < total) alpha[i + 3] = (v >>> 24) & 255;
		}
		int left = x - 1;
		int top = y - ascent - 1;
		int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
		for (int row = 0; row < th; row++) {
			int dy = top + row;
			if (dy < 0 || dy >= dh) continue;
			for (int col = 0; col < tw; col++) {
				int dx = left + col;
				if (dx < 0 || dx >= dw) continue;
				int a = alpha[row * tw + col];
				if (a == 0) continue;
				int di = dy * dw + dx;
				if (a >= 255) {
					dst[di] = 0xFF000000 | (r << 16) | (g << 8) | b;
				} else {
					int d = dst[di];
					int rr = (r * a + ((d >> 16) & 255) * (255 - a)) / 255;
					int gg = (g * a + ((d >> 8) & 255) * (255 - a)) / 255;
					int bb = (b * a + (d & 255) * (255 - a)) / 255;
					dst[di] = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
				}
			}
		}
	}

	/**
	 * Silent audio for now. It still drains at real playback speed, because the client paces its
	 * sound mixing by how fast this buffer empties.
	 */
	@Override
	public AudioOut openAudio(final int sampleRate, final int channels, final int bufferBytes) {
		final int cap = Math.max(bufferBytes, 2048);
		final long bytesPerSec = (long) sampleRate * Math.max(1, channels) * 2L;
		return new AudioOut() {
			private double fill;
			private long last = System.currentTimeMillis();

			private void drain() {
				long now = System.currentTimeMillis();
				fill = Math.max(0, fill - (now - last) * bytesPerSec / 1000.0);
				last = now;
			}

			@Override public synchronized int write(byte[] d, int o, int l) {
				drain();
				int n = (int) Math.min(l, cap - fill);
				fill += n;
				return n;
			}

			@Override public synchronized int available() {
				drain();
				return (int) (cap - fill);
			}

			@Override public synchronized void flush() { fill = 0; }
			@Override public void close() { }
		};
	}

	@Override public String dataDir() { return ""; }
}
