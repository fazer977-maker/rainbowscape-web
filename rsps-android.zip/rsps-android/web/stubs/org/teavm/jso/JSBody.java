package org.teavm.jso;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.METHOD)
public @interface JSBody { String[] params() default {}; String script(); }
