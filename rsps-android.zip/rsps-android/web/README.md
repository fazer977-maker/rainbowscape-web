# Rainbow Scape – browser client

The same 2009Scape (build 530) client as the Android app, compiled to JavaScript with TeaVM.
The Android code is untouched; `web/` reuses it and swaps the device-specific parts.

## How it works
- `prepare.py` copies `rt4/`, `shim/`, `org/`, `plugin/` from the Android project into `web/build/src`,
  applies a few small patches, then lays `overlay/` (replacement classes) and `src/web/` on top.
- TeaVM compiles that to `rainbow.js`. `static/index.html` is the Play page (canvas, touch/keyboard, settings).
- Browsers can't open raw TCP, so `proxy/ws-proxy.js` runs on the VPS and relays WebSocket <-> game ports 43594/43595.

## Build (GitHub Actions)
Push to GitHub. The "Build web client" workflow produces the artifact `rainbowscape-web`
(`index.html` + `rainbow.js`). Or locally: `python3 web/prepare.py && mvn -f web/pom.xml process-classes`
(output: `web/target/js/rainbow.js`).

## Bridge (on the VPS that runs the game server)
    cd web/proxy && npm install
    GAME_HOST=127.0.0.1 PORT=8081 ALLOWED_ORIGINS=https://yoursite.netlify.app node ws-proxy.js
Put it behind HTTPS (the page is https, so it needs wss://). Caddy example:
    play.yourdomain.com {
        reverse_proxy /ws* 127.0.0.1:8081
    }
Then in `static/index.html` set `wsUrl: "wss://play.yourdomain.com/ws"`.

## Known limits (first version)
- No sound yet (the client's audio runs silently).
- The cache is kept in memory, so each page load downloads game data again. Saving it to the
  browser (IndexedDB) is the next step.
- Software rendering only (same as the Android app). Touch: tap = click, hold = right click,
  drag = drag, two-finger drag = rotate camera, pinch = zoom, keyboard button top right.
- Not yet compiled in the build environment this was written in: the first TeaVM run may report
  unsupported classes; send the error log and they get fixed.
