#!/usr/bin/env bash
# Run by the GitHub Action: assemble, compile with TeaVM, build the site folder.
# On failure it writes the first error lines to the run's Summary page (one short screen).
cd "$(dirname "$0")/.." || exit 1          # -> rsps-android/
python3 web/prepare.py || exit 1
if ! mvn -B -f web/pom.xml process-classes > web/build.log 2>&1; then
  {
    echo '### Build errors (first lines)'
    echo '```'
    grep -v '^[[:space:]]*at ' web/build.log | grep -iE 'error|exception|not found|unsupported|cannot|missing' \
      | awk '!seen[$0]++' | head -45 | cut -c1-240
    echo '```'
  } >> "${GITHUB_STEP_SUMMARY:-/dev/stdout}"
  echo "=========== BUILD ERRORS (first lines) ==========="
  grep -v '^[[:space:]]*at ' web/build.log | grep -iE 'error|exception|not found|unsupported|cannot|missing' \
    | awk '!seen[$0]++' | head -45 | cut -c1-240
  echo "=========== END OF BUILD ERRORS ==========="
  grep -v '^[[:space:]]*at ' web/build.log | grep -iE 'error|exception|not found|unsupported|cannot|missing' \
    | awk '!seen[$0]++' | head -8 | cut -c1-200 | while IFS= read -r line; do echo "::error::${line}"; done
  exit 1
fi
mkdir -p ../site/play
cp site/index.html ../site/ || true
cp -n site/rainbowscape.apk ../site/ || true
cp -n site/play/config.js ../site/play/ || true
cp web/target/js/rainbow.js ../site/play/
cp web/static/index.html web/static/login.js web/static/silkscreen.ttf ../site/play/
echo "site built"
