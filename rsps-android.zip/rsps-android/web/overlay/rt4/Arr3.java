package rt4;

// Explicit 3-D array builders (TeaVM's multi-dimensional new failed in SceneGraph.init)
public final class Arr3 {
	public static int[][][] ints(int a, int b, int c) {
		int[][][] r = new int[a][][];
		for (int i = 0; i < a; i++) {
			r[i] = new int[b][];
			for (int j = 0; j < b; j++) {
				r[i][j] = new int[c];
			}
		}
		return r;
	}

	public static byte[][][] bytes(int a, int b, int c) {
		byte[][][] r = new byte[a][][];
		for (int i = 0; i < a; i++) {
			r[i] = new byte[b][];
			for (int j = 0; j < b; j++) {
				r[i][j] = new byte[c];
			}
		}
		return r;
	}

	public static Tile[][][] tiles(int a, int b, int c) {
		Tile[][][] r = new Tile[a][][];
		for (int i = 0; i < a; i++) {
			r[i] = new Tile[b][];
			for (int j = 0; j < b; j++) {
				r[i][j] = new Tile[c];
			}
		}
		return r;
	}

	public static LinkedList[][][] lists(int a, int b, int c) {
		LinkedList[][][] r = new LinkedList[a][][];
		for (int i = 0; i < a; i++) {
			r[i] = new LinkedList[b][];
			for (int j = 0; j < b; j++) {
				r[i][j] = new LinkedList[c];
			}
		}
		return r;
	}
}
