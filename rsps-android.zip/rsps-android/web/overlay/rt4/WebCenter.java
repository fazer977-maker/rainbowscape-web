package rt4;

/**
 * Web only: windows opened over the game (bank, dice, music...) are centred on the screen.
 * The stock layout centres them for a 765x503 area, which pushes them up on a short phone screen.
 */
public final class WebCenter {
    private static final boolean[] SKIP = new boolean[128];
    static {
        // containers MobileLayout already positions (chat, tab icons, tab panel)
        for (int i : new int[] {23, 24, 25, 40, 55, 70, 71, 72, 73, 74, 75, 76, 77}) SKIP[i] = true;
    }
    private static String lastLog = "";

    private WebCenter() {}

    public static void apply() {
        if (client.gameState != 30 || InterfaceList.topLevelInterface != 746 || InterfaceList.openInterfaces == null) {
            return;
        }
        Component[][] all = InterfaceList.components;
        if (all == null || all.length <= 746 || all[746] == null) {
            return;
        }
        int w = GameShell.canvasWidth, h = GameShell.canvasHeight;
        StringBuilder log = new StringBuilder();
        for (ComponentPointer p = (ComponentPointer) InterfaceList.openInterfaces.head(); p != null; p = (ComponentPointer) InterfaceList.openInterfaces.next()) {
            int parentIface = (int) (p.key >> 16), parentComp = (int) (p.key & 0xFFFF);
            if (parentIface != 746 || parentComp < 0 || parentComp >= all[746].length || (parentComp < 128 && SKIP[parentComp])) {
                continue;
            }
            Component box = all[746][parentComp];
            int id = p.interfaceId;
            if (box == null || id < 0 || id >= all.length || all[id] == null || all[id].length == 0 || all[id][0] == null) {
                continue;
            }
            Component root = all[id][0];
            int rw = root.width, rh = root.height;
            log.append(parentComp).append("->").append(id).append(" t").append(p.type).append(" box ").append(box.x).append(',').append(box.y).append(' ').append(box.width).append('x').append(box.height).append(" root ").append(rw).append('x').append(rh).append(";");
            if (rw < 60 || rh < 40 || rw > w || rh > h || (box.width >= w && box.height >= h)) {
                continue;     // full screen windows and tiny widgets stay as they are
            }
            box.x = (w - rw) / 2;
            box.y = (h - rh) / 2;
            box.width = rw;
            box.height = rh;
        }
        String s = log.toString();
        if (s.length() > 0 && !s.equals(lastLog)) {
            lastLog = s;
            web.Js.log("windows: " + s);
        }
    }
}
