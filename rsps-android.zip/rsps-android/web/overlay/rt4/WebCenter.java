package rt4;

/**
 * Web only: windows opened over the game (bank, dice, music...) are centred on the screen.
 * The stock layout centres them for a 765x503 area, which pushes them up on a short phone screen.
 */
public final class WebCenter {
    private static final boolean[] SKIP = new boolean[128];
    static {
        // containers MobileLayout already positions (chat, tab icons, tab panel)
        for (int i : new int[] {23, 24, 25, 40, 55, 70, 71, 72, 73, 74, 75, 76, 77}) SKIP[i] = true;
    }
    private static String lastLog = "";

    private static volatile int[] rects = new int[0];
    private WebCenter() {}

    /** True when (x, y) is over a window opened above the game (bank, dice...), so a drag there is a mouse drag, not a camera turn. */
    public static boolean over(int x, int y) {
        int[] r = rects;
        for (int i = 0; i + 3 < r.length; i += 4) {
            if (x >= r[i] && x < r[i] + r[i + 2] && y >= r[i + 1] && y < r[i + 1] + r[i + 3]) return true;
        }
        return false;
    }

    public static void apply() {
        if (client.gameState != 30 || InterfaceList.topLevelInterface != 746 || InterfaceList.openInterfaces == null) {
            return;
        }
        Component[][] all = InterfaceList.components;
        if (all == null || all.length <= 746 || all[746] == null) {
            return;
        }
        int w = GameShell.canvasWidth, h = GameShell.canvasHeight;
        StringBuilder log = new StringBuilder();
        int[] found = new int[16];
        int nf = 0;
        for (ComponentPointer p = (ComponentPointer) InterfaceList.openInterfaces.head(); p != null; p = (ComponentPointer) InterfaceList.openInterfaces.next()) {
            int parentIface = (int) (p.key >> 16), parentComp = (int) (p.key & 0xFFFF);
            if (parentIface != 746 || parentComp < 0 || parentComp >= all[746].length || (parentComp < 128 && SKIP[parentComp])) {
                continue;
            }
            Component box = all[746][parentComp];
            int id = p.interfaceId;
            if (box == null || id < 0 || id >= all.length || all[id] == null || all[id].length == 0 || all[id][0] == null) {
                continue;
            }
            Component root = all[id][0];
            int rw = root.width, rh = root.height;
            log.append(parentComp).append("->").append(id).append(" t").append(p.type).append(" box ").append(box.x).append(',').append(box.y).append(' ').append(box.width).append('x').append(box.height).append(" root ").append(rw).append('x').append(rh).append(";");
            if (rw >= 150 && rw <= 200 && rh >= 200 && rh <= 270) {
                continue;     // 190x261 tab panels are placed by MobileLayout
            }
            if (rw < 60 || rh < 40 || rw > w || rh > h || (box.width >= w && box.height >= h)) {
                continue;     // full screen windows and tiny widgets stay as they are
            }
            box.x = Math.max(0, (MobileLayout.freeRight() - rw) / 2);
            box.y = (h - rh) / 2;
            box.width = rw;
            box.height = rh;
            if (nf < 16) { found[nf++] = box.x; found[nf++] = box.y; found[nf++] = rw; found[nf++] = rh; }
        }
        int[] out = new int[nf];
        System.arraycopy(found, 0, out, 0, nf);
        rects = out;
        String s = log.toString();
        if (s.length() > 0 && !s.equals(lastLog)) {
            lastLog = s;
            web.Js.log("windows: " + s);
        }
    }
}
