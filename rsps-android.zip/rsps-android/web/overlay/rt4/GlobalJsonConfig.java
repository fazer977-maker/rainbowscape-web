package rt4;

import web.Js;

/** Browser build: settings come from the page (window.RS_CONFIG) instead of a config.json file. */
public class GlobalJsonConfig {
	public static GlobalJsonConfig instance = null;

	public static void load(String path) {
		GlobalJsonConfig c = new GlobalJsonConfig();
		c.ip_management = Js.cfgStr("host");
		c.ip_address = c.ip_management;
		c.world = Js.cfgInt("world");
		c.server_port = Js.cfgInt("serverPort");
		c.wl_port = Js.cfgInt("wlPort");
		c.js5_port = Js.cfgInt("js5Port");
		instance = c;
	}

	// ----

	String ip_management;
	String ip_address;
	int world;
	int server_port;
	int wl_port;
	int js5_port;
	boolean mouseWheelZoom = GlobalConfig.MOUSEWHEEL_ZOOM;
	public String pluginsFolder = "plugins";
}
