package rt4;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;

/**
 * Browser build: the "file" lives in memory (sparse 64 KB pages) instead of on disk.
 * Same API as the desktop/Android class, so the cache code does not change.
 */
public final class FileOnDisk {
	private static final int PAGE = 65536;

	private byte[][] pages = new byte[16][];
	private long length = 0L;
	private long pos = 0L;
	private final long maxLength;
	private final File file;
	private boolean closed;

	public FileOnDisk(File file, String mode, long maxLength) throws IOException {
		if (maxLength == -1L) {
			maxLength = Long.MAX_VALUE;
		}
		this.file = file;
		this.maxLength = maxLength;
	}

	public final void seek(long offset) throws IOException {
		this.pos = offset;
	}

	private byte[] page(int index, boolean create) {
		if (index >= this.pages.length) {
			if (!create) {
				return null;
			}
			byte[][] bigger = new byte[Math.max(index + 1, this.pages.length * 2)][];
			System.arraycopy(this.pages, 0, bigger, 0, this.pages.length);
			this.pages = bigger;
		}
		byte[] p = this.pages[index];
		if (p == null && create) {
			p = new byte[PAGE];
			this.pages[index] = p;
		}
		return p;
	}

	public final void write(byte[] src, int len, int off) throws IOException {
		if (this.pos + (long) len > this.maxLength) {
			throw new EOFException();
		}
		int done = 0;
		while (done < len) {
			long at = this.pos + done;
			byte[] p = page((int) (at / PAGE), true);
			int po = (int) (at % PAGE);
			int n = Math.min(len - done, PAGE - po);
			System.arraycopy(src, off + done, p, po, n);
			done += n;
		}
		this.pos += len;
		if (this.pos > this.length) {
			this.length = this.pos;
		}
	}

	public final int read(int off, int len, byte[] bytes) throws IOException {
		if (this.pos >= this.length) {
			return -1;
		}
		int want = (int) Math.min((long) len, this.length - this.pos);
		int done = 0;
		while (done < want) {
			long at = this.pos + done;
			byte[] p = page((int) (at / PAGE), false);
			int po = (int) (at % PAGE);
			int n = Math.min(want - done, PAGE - po);
			if (p == null) {
				for (int i = 0; i < n; i++) {
					bytes[off + done + i] = 0;
				}
			} else {
				System.arraycopy(p, po, bytes, off + done, n);
			}
			done += n;
		}
		this.pos += want;
		return want;
	}

	public final void close() throws IOException {
		this.closed = true;
	}

	public final long length() throws IOException {
		return this.length;
	}

	public final File getFile() {
		return this.file;
	}
}
