package rt4;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import web.Js;

/**
 * Browser build: the "file" lives in memory (sparse 64 KB pages) and is mirrored into the browser's
 * IndexedDB, so the game only downloads its data once. Same API as the desktop/Android class.
 */
public final class FileOnDisk {
	private static final int PAGE = 65536;
	private static final ArrayList<FileOnDisk> ALL = new ArrayList<FileOnDisk>();
	private static boolean flusher;

	private byte[][] pages = new byte[16][];
	private boolean[] dirty = new boolean[16];
	private boolean metaDirty;
	private long length = 0L;
	private long pos = 0L;
	private final long maxLength;
	private final File file;
	private final String name;
	private final boolean big;
	private boolean closed;

	public FileOnDisk(File file, String mode, long maxLength) throws IOException {
		if (maxLength == -1L) {
			maxLength = Long.MAX_VALUE;
		}
		this.file = file;
		this.maxLength = maxLength;
		this.name = file.getName();
		this.big = this.name.startsWith("main_file_cache");
		int saved = Js.cacheLen(this.name);
		if (saved > 0) {
			this.length = saved;
		}
		synchronized (ALL) {
			ALL.add(this);
			if (!flusher) {
				flusher = true;
				Thread t = new Thread(new Runnable() {
					@Override
					public void run() {
						while (true) {
							try {
								Thread.sleep(700);
							} catch (InterruptedException e) {
							}
							flushAll();
						}
					}
				});
				t.setDaemon(true);
				t.start();
			}
		}
	}

	static void flushAll() {
		for (int i = 0; i < ALL.size(); i++) {
			ALL.get(i).flush();
		}
	}

	private void flush() {
		for (int i = 0; i < this.dirty.length; i++) {
			if (this.dirty[i]) {
				this.dirty[i] = false;
				byte[] p = i < this.pages.length ? this.pages[i] : null;
				if (p != null) {
					Js.cachePut(this.name, i, p, PAGE);
				}
			}
		}
		if (this.metaDirty) {
			this.metaDirty = false;
			Js.cacheMeta(this.name, (int) this.length);
		}
	}

	public final void seek(long offset) throws IOException {
		this.pos = offset;
	}

	private void grow(int index) {
		int size = Math.max(index + 1, this.pages.length * 2);
		byte[][] bigger = new byte[size][];
		System.arraycopy(this.pages, 0, bigger, 0, this.pages.length);
		this.pages = bigger;
		boolean[] d = new boolean[size];
		System.arraycopy(this.dirty, 0, d, 0, this.dirty.length);
		this.dirty = d;
	}

	private byte[] page(int index, boolean create) {
		byte[] p = index < this.pages.length ? this.pages[index] : null;
		if (p == null) {
			boolean saved = Js.cacheHas(this.name, index) == 1;
			if (!saved && !create) {
				return null;
			}
			if (index >= this.pages.length) {
				grow(index);
			}
			p = new byte[PAGE];
			if (saved) {
				for (int i = 0; i < PAGE; i += 4) {
					int v = Js.cacheGet4(this.name, index, i);
					p[i] = (byte) v;
					p[i + 1] = (byte) (v >> 8);
					p[i + 2] = (byte) (v >> 16);
					p[i + 3] = (byte) (v >> 24);
				}
				if (this.big) {
					Js.cacheDrop(this.name, index);
				}
			}
			this.pages[index] = p;
		}
		return p;
	}

	public final void write(byte[] src, int len, int off) throws IOException {
		if (this.pos + (long) len > this.maxLength) {
			throw new EOFException();
		}
		int done = 0;
		while (done < len) {
			long at = this.pos + done;
			int pi = (int) (at / PAGE);
			byte[] p = page(pi, true);
			int po = (int) (at % PAGE);
			int n = Math.min(len - done, PAGE - po);
			System.arraycopy(src, off + done, p, po, n);
			this.dirty[pi] = true;
			done += n;
		}
		this.pos += len;
		if (this.pos > this.length) {
			this.length = this.pos;
			this.metaDirty = true;
		}
	}

	public final int read(int off, int len, byte[] bytes) throws IOException {
		if (this.pos >= this.length) {
			return -1;
		}
		int want = (int) Math.min((long) len, this.length - this.pos);
		int done = 0;
		while (done < want) {
			long at = this.pos + done;
			byte[] p = page((int) (at / PAGE), false);
			int po = (int) (at % PAGE);
			int n = Math.min(want - done, PAGE - po);
			if (p == null) {
				for (int i = 0; i < n; i++) {
					bytes[off + done + i] = 0;
				}
			} else {
				System.arraycopy(p, po, bytes, off + done, n);
			}
			done += n;
		}
		this.pos += want;
		return want;
	}

	public final void close() throws IOException {
		this.closed = true;
		flush();
	}

	public final long length() throws IOException {
		return this.length;
	}

	public final File getFile() {
		return this.file;
	}
}
