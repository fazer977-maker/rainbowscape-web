package rt4;

import shim.applet.Applet;
import shim.awt.*;
import shim.awt.Component;
import shim.net.Socket;
import web.Js;

import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;

/**
 * Browser build of the privileged-request thread. Same API as the desktop class, but sockets are
 * WebSockets, the cache lives in memory, and everything that needs the JVM (reflection checks,
 * full screen, OpenGL natives, custom cursors) is reported as unsupported.
 */
public final class SignLink implements Runnable {
	public static String javaVersion = "1.8";
	public static String osName = "browser";
	public static String javaVendor = "Browser";
	public static Method setFocusCycleRoot;
	public static Method setFocusTraversalKeysEnabled;
	public static final int clientMode = 1;

	private static volatile long breakConnectionsUntil = 0L;

	private AudioSource audioSource;
	public FileOnDisk cacheData;
	private PrivilegedRequest requestQueueTail = null;
	private boolean stop;
	public FileOnDisk cacheMasterIndex;
	public FileOnDisk uid;
	private PrivilegedRequest requestQueueHead = null;
	public Applet applet;
	private final String cacheSubDir;
	private final int cacheId;
	public EventQueue eventQueue;
	public FileOnDisk[] cacheIndexes;
	private final Thread thread;

	public static File getFile(String cacheSubDir, int storeId, String name) {
		return new File(name);
	}

	public SignLink(Applet applet, int cacheId, String cacheSubDir, int archiveCount) throws Exception {
		this.cacheSubDir = cacheSubDir;
		this.cacheId = cacheId;
		this.applet = applet;
		try {
			this.eventQueue = Toolkit.getDefaultToolkit().getSystemEventQueue();
		} catch (Throwable ex) {
		}
		this.uid = new FileOnDisk(new File("random.dat"), "rw", 25L);
		this.cacheData = new FileOnDisk(new File("main_file_cache.dat2"), "rw", 104857600L);
		this.cacheMasterIndex = new FileOnDisk(new File("main_file_cache.idx255"), "rw", 1048576L);
		this.cacheIndexes = new FileOnDisk[archiveCount];
		for (int i = 0; i < archiveCount; i++) {
			this.cacheIndexes[i] = new FileOnDisk(new File("main_file_cache.idx" + i), "rw", 1048576L);
		}
		this.stop = false;
		this.thread = new Thread(this);
		this.thread.setDaemon(true);
		this.thread.start();
	}

	public final void breakConnection() {
		breakConnectionsUntil = MonotonicClock.currentTimeMillis() + 5000L;
	}

	public final boolean isFullScreenSupported() {
		return false;
	}

	public final PrivilegedRequest openPreferences(String cacheSubDir) {
		return this.enqueue(12, 0, cacheSubDir, 0);
	}

	public final PrivilegedRequest setCursor(int[] pixels, int width, Component component, Point hotSpot, int height) {
		return this.enqueue(17, height, new Object[] { component, pixels, hotSpot }, width);
	}

	private PrivilegedRequest enqueue(int type, int intArg1, Object objectArg, int intArg2) {
		PrivilegedRequest request = new PrivilegedRequest();
		request.intArg1 = intArg1;
		request.intArg2 = intArg2;
		request.type = type;
		request.objectArg = objectArg;
		synchronized (this) {
			if (this.requestQueueTail == null) {
				this.requestQueueTail = this.requestQueueHead = request;
			} else {
				this.requestQueueTail.next = request;
				this.requestQueueTail = request;
			}
			this.notify();
			return request;
		}
	}

	public final PrivilegedRequest exitFullScreen(Frame frame) {
		return this.enqueue(7, 0, frame, 0);
	}

	public final PrivilegedRequest openUrlStream(URL url) {
		return this.enqueue(4, 0, url, 0);
	}

	public final PrivilegedRequest openSocket(String hostname, int port) {
		System.out.println("openSocket(" + hostname + ":" + port + ")");
		return this.enqueue(1, 0, hostname, port);
	}

	public final PrivilegedRequest unloadGlNatives(Class targetClass) {
		return this.enqueue(11, 0, targetClass, 0);
	}

	public final PrivilegedRequest getDeclaredMethod(Class targetClass, Class[] parameterTypes, String name) {
		return this.enqueue(8, 0, new Object[] { targetClass, name, parameterTypes }, 0);
	}

	@Override
	public final void run() {
		while (true) {
			PrivilegedRequest request;
			synchronized (this) {
				while (true) {
					if (this.stop) {
						return;
					}
					if (this.requestQueueHead != null) {
						request = this.requestQueueHead;
						this.requestQueueHead = this.requestQueueHead.next;
						if (this.requestQueueHead == null) {
							this.requestQueueTail = null;
						}
						break;
					}
					try {
						this.wait();
					} catch (InterruptedException ex) {
					}
				}
			}
			try {
				int type = request.type;
				if (type == 1) {
					if (breakConnectionsUntil > MonotonicClock.currentTimeMillis()) {
						throw new IOException();
					}
					request.result = new Socket((String) request.objectArg, request.intArg2);
				} else if (type == 2) {
					Thread t = new Thread((Runnable) request.objectArg);
					t.setDaemon(true);
					t.start();
					request.result = t;
				} else if (type == 3) {
					request.result = (request.intArg2 >> 24 & 0xFF) + "." + (request.intArg2 >> 16 & 0xFF) + "." + (request.intArg2 >> 8 & 0xFF) + "." + (request.intArg2 & 0xFF);
				} else if (type == 12) {
					request.result = new FileOnDisk(new File("preferences.dat"), "rw", 10000L);
				} else if (type == 16) {
					String url = (String) request.objectArg;
					if (url.startsWith("http://") || url.startsWith("https://")) {
						Js.openUrl(url);
					}
					request.result = null;
				} else if (type == 14 || type == 15 || type == 17 || type == 10) {
					// cursor and GL-native requests: nothing to do in a browser
					request.result = null;
				} else {
					throw new Exception();
				}
				request.status = 1;
			} catch (Throwable ex) {
				Js.log("signlink request type " + request.type + " failed: " + ex);
				request.status = 2;
			}
		}
	}

	public final PrivilegedRequest loadGlNatives(Class targetClass) {
		return this.enqueue(10, 0, targetClass, 0);
	}

	public final void stop() {
		synchronized (this) {
			this.stop = true;
			this.notifyAll();
		}
	}

	public final AudioSource getAudioSource() {
		return this.audioSource;
	}

	public final PrivilegedRequest getDeclaredField(String name, Class targetClass) {
		return this.enqueue(9, 0, new Object[] { targetClass, name }, 0);
	}

	public final PrivilegedRequest getReverseDns(int ip) {
		return this.enqueue(3, 0, null, ip);
	}

	public final PrivilegedRequest enterFullScreen(int bitDepth, int height, int width) {
		return this.enqueue(6, bitDepth << 16, null, (width << 16) + height);
	}

	public final PrivilegedRequest startThread(int priority, Runnable runnable) {
		return this.enqueue(2, 0, runnable, priority);
	}

	public final PrivilegedRequest openUrl(String url) {
		return this.enqueue(16, 0, url, 0);
	}

	public final PrivilegedRequest getDisplayModes() {
		return this.enqueue(5, 0, null, 0);
	}
}
