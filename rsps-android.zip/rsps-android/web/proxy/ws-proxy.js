// Rainbow Scape web bridge: browser WebSocket  <->  game server TCP port.
//
//   npm install ws
//   GAME_HOST=127.0.0.1 PORT=8081 node ws-proxy.js
//
// The page connects to  wss://your-domain/ws?port=43594  (game)  or  ?port=43595  (cache/world list).
// Put this behind HTTPS (Caddy or nginx) so the https website is allowed to open it.
const net = require('net');
const http = require('http');
const { WebSocketServer } = require('ws');

const GAME_HOST = process.env.GAME_HOST || '127.0.0.1';
const PORT = parseInt(process.env.PORT || '8081', 10);
const ALLOWED_PORTS = (process.env.ALLOWED_PORTS || '43594,43595').split(',').map(Number);
const ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);

const server = http.createServer((req, res) => { res.writeHead(200); res.end('rainbow scape bridge\n'); });
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 1 << 20 });

wss.on('connection', (ws, req) => {
  const origin = req.headers.origin || '';
  if (ORIGINS.length && !ORIGINS.includes(origin)) { ws.close(1008, 'origin'); return; }
  const port = parseInt(new URL(req.url, 'http://x').searchParams.get('port'), 10);
  if (!ALLOWED_PORTS.includes(port)) { ws.close(1008, 'port'); return; }

  const tcp = net.connect(port, GAME_HOST);
  tcp.setNoDelay(true);
  let alive = true;
  ws.on('pong', () => { alive = true; });
  const ping = setInterval(() => {
    if (!alive) { ws.terminate(); return; }
    alive = false;
    try { ws.ping(); } catch (e) {}
  }, 30000);

  tcp.on('data', d => { if (ws.readyState === 1) ws.send(d, { binary: true }); });
  tcp.on('error', () => ws.close());
  tcp.on('close', () => ws.close());
  ws.on('message', d => { if (!tcp.destroyed) tcp.write(d); });
  ws.on('close', () => { clearInterval(ping); tcp.destroy(); });
  ws.on('error', () => tcp.destroy());
});

server.listen(PORT, () => console.log('bridge on :' + PORT + ' -> ' + GAME_HOST + ' ports ' + ALLOWED_PORTS));
