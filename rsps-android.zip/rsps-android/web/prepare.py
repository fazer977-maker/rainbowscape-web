#!/usr/bin/env python3
"""Assemble the browser build's source tree into web/build/src.

Copies the shared client (rt4, shim, org, plugin) from the Android project, applies the small
text patches below, then lays the web/overlay and web/src files on top.
"""
import os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
JAVA = os.path.join(HERE, '..', 'app', 'src', 'main', 'java')
OUT = os.path.join(HERE, 'build', 'src')

def read(p):
    with open(p, encoding='utf-8') as f: return f.read()
def write(p, s):
    with open(p, 'w', encoding='utf-8') as f: f.write(s)

def patch(rel, fn):
    p = os.path.join(OUT, rel)
    s = read(p)
    n = fn(s)
    if n == s:
        sys.exit('patch did nothing: ' + rel)
    write(p, n)

shutil.rmtree(OUT, ignore_errors=True)
os.makedirs(OUT)
for d in ('rt4', 'shim', 'org', 'plugin'):
    shutil.copytree(os.path.join(JAVA, d), os.path.join(OUT, d))

# overlays replace whole files; src adds the web package
for root in ('overlay', 'src'):
    base = os.path.join(HERE, root)
    for dp, _, files in os.walk(base):
        for f in files:
            dst = os.path.join(OUT, os.path.relpath(os.path.join(dp, f), base))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy(os.path.join(dp, f), dst)

# java.net.Socket -> the WebSocket-backed shim (every file that imports it)
for dp, _, files in os.walk(os.path.join(OUT, 'rt4')):
    for f in files:
        p = os.path.join(dp, f)
        t = read(p)
        if 'import java.net.Socket;' in t:
            write(p, t.replace('import java.net.Socket;', 'import shim.net.Socket;'))

# screenshots need java.io/ImageIO/Robot: not in a browser
def no_screenshot(s):
    a = s.index('public void saveScreenshot(String filename, String... subfolders) {')
    b = s.index('@OriginalMember(owner = "client!lb", name = "a", descriptor = "(Z)V")', a)
    return s[:a] + 'public void saveScreenshot(String filename, String... subfolders) {\n\t}\n\n\t' + s[b:]
patch('rt4/client.java', no_screenshot)

# the server's reflection probes can't run in a browser: answer "class not found"
patch('rt4/ReflectionCheck.java', lambda s: s.replace('return Class.forName(name);', 'throw new ClassNotFoundException(name);'))

# account saving used java.nio.file; the browser build keeps the list in memory (this page load only)
def memory_accounts(s):
    a = s.index('    private static File file() {')
    b = s.index('    /** Called when a login attempt starts. */')
    mem = """    private static final java.util.List<String[]> MEM = new java.util.ArrayList<String[]>();

    /** Saved accounts, most recently used first: {username, password, lastLoginMillis}. */
    public static synchronized java.util.List<String[]> load(Object dir) {
        return new java.util.ArrayList<String[]>(MEM);
    }

    public static synchronized void remove(Object dir, String name) {
        for (int i = MEM.size() - 1; i >= 0; i--) {
            if (MEM.get(i)[0].equalsIgnoreCase(name)) MEM.remove(i);
        }
    }

    public static synchronized void forgetAll(Object dir) {
        MEM.clear();
    }

"""
    s = s[:a] + mem + s[b:]
    a = s.index('    public static synchronized void success() {')
    b = s.index('    /** Queue a login from the Android login screen')
    ok = """    public static synchronized void success() {
        if (!rememberMe || pendingUser == null || pendingUser.isEmpty()) {
            return;
        }
        for (int i = MEM.size() - 1; i >= 0; i--) {
            if (MEM.get(i)[0].equalsIgnoreCase(pendingUser)) MEM.remove(i);
        }
        MEM.add(0, new String[] {pendingUser, pendingPass, String.valueOf(System.currentTimeMillis())});
        while (MEM.size() > MAX_ACCOUNTS) MEM.remove(MEM.size() - 1);
    }

"""
    s = s[:a] + ok + s[b:]
    return s.replace('import java.io.File;\n', '').replace('import java.nio.file.Files;\n', '').replace('import java.nio.charset.StandardCharsets;\n', '')
patch('rt4/SavedAccount.java', memory_accounts)

# HD (OpenGL) rendering can't exist in a browser; cut the JOGL entry points so only the
# software renderer is reachable (the Android build already does the same at runtime).
def no_jogl(s):
    a = s.index('GLProfile profile = GLProfile.getDefault();')
    b = s.index('} catch (@Pc(30) Throwable ex) {', a)
    s = s[:a] + 'if (true) return;\n\t\t' + s[b:]
    a = s.index('GLProfile profile = GLProfile.get(GLProfile.GL3bc);')
    b = s.index('} catch (@Pc(103) Throwable ex) {', a)
    s = s[:a] + 'throw new UnsupportedOperationException();\n\t\t' + s[b:]
    # never touch the JOGL window/context classes (their code can't be compiled for a browser)
    a = s.index('if (window != null) {')
    b = s.index('window = null;', a)
    s = s[:a] + s[b:]
    s = s.replace('private static JAWTWindow window;', 'private static Object window;')
    s = s.replace('private static GLContext context;', 'private static Object context;')
    s = s.replace('private static JAWTWindow unsupportedWindow()', 'private static Object unsupportedWindow()')
    return s
patch('rt4/GlRenderer.java', no_jogl)

# TeaVM can't do these JVM-only calls (found by the first real build):
def rc(s):
    s = s.replace('value = field.getInt(null);', 'value = 0;')
    s = s.replace('field.setInt(null, check.fieldValues[j]);', ';')
    s = s.replace('ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(args[k]));', 'Object stream = noStream();')
    helper = "\n\tprivate static Object noStream() throws ClassNotFoundException, InvalidClassException, StreamCorruptedException, OptionalDataException, IOException {\n\t\treturn null;\n\t}\n}"
    i = s.rstrip().rfind('}')
    s = s[:i] + helper + "\n"
    s = s.replace('params[k] = stream.readObject();', 'params[k] = stream;')
    return s
patch('rt4/ReflectionCheck.java', rc)
patch('rt4/GameShell.java', lambda s: s.replace('maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1048576L) + 1;', 'maxMemory = 256;'))
patch('shim/platform/Platforms.java', lambda s: s.replace('System.exit(code);', 'throw new IllegalStateException("client exit " + code);'))

print('assembled', OUT)

# --- debug logging for the JS5 loader (shows up in the on-screen log) ---
def js5_debug(s):
    import re
    s = re.sub(r'(catch \(@Pc\(\d+\) IOException ex\) \{)', r'\1\n\t\t\tweb.Js.log("js5 io error #" + this.errors + ": " + ex);', s)
    s = s.replace('if (matched == null) {\n\t\t\t\t\t\t\t\tthrow new IOException();',
                  'if (matched == null) {\n\t\t\t\t\t\t\t\tweb.Js.log("js5 unmatched header a=" + readLen + " g=" + j + " flag=" + headerByte + " len=" + compressedLen + " urgent=" + this.inFlightUrgentRequests.size() + " prefetch=" + this.inFlightPrefetchRequests.size());\n\t\t\t\t\t\t\t\tthrow new IOException();')
    # faster downloads: more requests in flight, more reads handled per tick
    s = s.replace('getPrefetchRequestCount() >= 20', 'getPrefetchRequestCount() >= 64')
    s = s.replace('getUrgentRequestCount() >= 20', 'getUrgentRequestCount() >= 64')
    s = s.replace('getPrefetchRequestCount() < 20', 'getPrefetchRequestCount() < 64')
    s = s.replace('iteration < 100; iteration++', 'iteration < 400; iteration++')
    return s
patch('rt4/Js5NetQueue.java', js5_debug)

# --- crash breadcrumbs: say which phase of the main loop / redraw threw ---
def client_crumbs(s):
    def wrap(call, name):
        return 'try { ' + call + ' } catch (RuntimeException ex) { web.Js.log("CRASH in ' + name + ': " + ex); throw ex; }'
    s = s.replace('LoginManager.rebuildMap();\n\t\t}\n\t\tif (gameState == 10)', wrap('LoginManager.rebuildMap();', 'rebuildMap') + '\n\t\t}\n\t\tif (gameState == 10)')
    s = s.replace('\t\t\tthis.mainUpdate();\n\t\t\tCreateManager.loop();\n\t\t\tLoginManager.loopAuto();\n\t\t\tLoginManager.loop();',
        '\t\t\t' + wrap('this.mainUpdate();', 'mainUpdate') + '\n\t\t\t' + wrap('CreateManager.loop();', 'CreateManager.loop') + '\n\t\t\t' + wrap('LoginManager.loopAuto();', 'loopAuto') + '\n\t\t\t' + wrap('LoginManager.loop();', 'LoginManager.loop10'))
    s = s.replace('} else if (gameState == 30) {\n\t\t\tProtocol.loop();', '} else if (gameState == 30) {\n\t\t\t' + wrap('Protocol.loop();', 'Protocol.loop'))
    s = s.replace('\t\t\tLoginManager.loop();\n\t\t\tif (LoginManager.reply != -3)', '\t\t\t' + wrap('LoginManager.loop();', 'LoginManager.loop40') + '\n\t\t\tif (LoginManager.reply != -3)')
    s = s.replace('protected final void mainRedraw() {',
        'protected final void mainRedraw() {\n\t\ttry { mainRedraw0(); } catch (RuntimeException ex) { web.Js.log("CRASH in mainRedraw gs=" + gameState + ": " + ex); throw ex; }\n\t}\n\n\tprotected final void mainRedraw0() {', 1)
    return s
patch('rt4/client.java', client_crumbs)
