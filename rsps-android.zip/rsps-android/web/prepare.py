#!/usr/bin/env python3
"""Assemble the browser build's source tree into web/build/src.

Copies the shared client (rt4, shim, org, plugin) from the Android project, applies the small
text patches below, then lays the web/overlay and web/src files on top.
"""
import os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
JAVA = os.path.join(HERE, '..', 'app', 'src', 'main', 'java')
OUT = os.path.join(HERE, 'build', 'src')

def read(p):
    with open(p, encoding='utf-8') as f: return f.read()
def write(p, s):
    with open(p, 'w', encoding='utf-8') as f: f.write(s)

def patch(rel, fn):
    p = os.path.join(OUT, rel)
    s = read(p)
    n = fn(s)
    if n == s:
        sys.exit('patch did nothing: ' + rel)
    write(p, n)

shutil.rmtree(OUT, ignore_errors=True)
os.makedirs(OUT)
for d in ('rt4', 'shim', 'org', 'plugin'):
    shutil.copytree(os.path.join(JAVA, d), os.path.join(OUT, d))

# overlays replace whole files; src adds the web package
for root in ('overlay', 'src'):
    base = os.path.join(HERE, root)
    for dp, _, files in os.walk(base):
        for f in files:
            dst = os.path.join(OUT, os.path.relpath(os.path.join(dp, f), base))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy(os.path.join(dp, f), dst)

# java.net.Socket -> the WebSocket-backed shim (every file that imports it)
for dp, _, files in os.walk(os.path.join(OUT, 'rt4')):
    for f in files:
        p = os.path.join(dp, f)
        t = read(p)
        if 'import java.net.Socket;' in t:
            write(p, t.replace('import java.net.Socket;', 'import shim.net.Socket;'))

# screenshots need java.io/ImageIO/Robot: not in a browser
def no_screenshot(s):
    a = s.index('public void saveScreenshot(String filename, String... subfolders) {')
    b = s.index('@OriginalMember(owner = "client!lb", name = "a", descriptor = "(Z)V")', a)
    return s[:a] + 'public void saveScreenshot(String filename, String... subfolders) {\n\t}\n\n\t' + s[b:]
patch('rt4/client.java', no_screenshot)

# the server's reflection probes can't run in a browser: answer "class not found"
patch('rt4/ReflectionCheck.java', lambda s: s.replace('return Class.forName(name);', 'throw new ClassNotFoundException(name);'))

# account saving used java.nio.file; the browser build keeps the list in memory (this page load only)
def memory_accounts(s):
    a = s.index('    private static File file() {')
    b = s.index('    /** Called when a login attempt starts. */')
    mem = """    private static final java.util.List<String[]> MEM = new java.util.ArrayList<String[]>();

    /** Saved accounts, most recently used first: {username, password, lastLoginMillis}. */
    public static synchronized java.util.List<String[]> load(Object dir) {
        return new java.util.ArrayList<String[]>(MEM);
    }

    public static synchronized void remove(Object dir, String name) {
        for (int i = MEM.size() - 1; i >= 0; i--) {
            if (MEM.get(i)[0].equalsIgnoreCase(name)) MEM.remove(i);
        }
    }

    public static synchronized void forgetAll(Object dir) {
        MEM.clear();
    }

"""
    s = s[:a] + mem + s[b:]
    a = s.index('    public static synchronized void success() {')
    b = s.index('    /** Queue a login from the Android login screen')
    ok = """    public static synchronized void success() {
        if (!rememberMe || pendingUser == null || pendingUser.isEmpty()) {
            return;
        }
        for (int i = MEM.size() - 1; i >= 0; i--) {
            if (MEM.get(i)[0].equalsIgnoreCase(pendingUser)) MEM.remove(i);
        }
        MEM.add(0, new String[] {pendingUser, pendingPass, String.valueOf(System.currentTimeMillis())});
        while (MEM.size() > MAX_ACCOUNTS) MEM.remove(MEM.size() - 1);
    }

"""
    s = s[:a] + ok + s[b:]
    return s.replace('import java.io.File;\n', '').replace('import java.nio.file.Files;\n', '').replace('import java.nio.charset.StandardCharsets;\n', '')
patch('rt4/SavedAccount.java', memory_accounts)

# HD (OpenGL) rendering can't exist in a browser; cut the JOGL entry points so only the
# software renderer is reachable (the Android build already does the same at runtime).
def no_jogl(s):
    a = s.index('GLProfile profile = GLProfile.getDefault();')
    b = s.index('} catch (@Pc(30) Throwable ex) {', a)
    s = s[:a] + 'if (true) return;\n\t\t' + s[b:]
    a = s.index('GLProfile profile = GLProfile.get(GLProfile.GL3bc);')
    b = s.index('} catch (@Pc(103) Throwable ex) {', a)
    s = s[:a] + 'throw new UnsupportedOperationException();\n\t\t' + s[b:]
    # never touch the JOGL window/context classes (their code can't be compiled for a browser)
    a = s.index('if (window != null) {')
    b = s.index('window = null;', a)
    s = s[:a] + s[b:]
    s = s.replace('private static JAWTWindow window;', 'private static Object window;')
    s = s.replace('private static GLContext context;', 'private static Object context;')
    s = s.replace('private static JAWTWindow unsupportedWindow()', 'private static Object unsupportedWindow()')
    return s
patch('rt4/GlRenderer.java', no_jogl)

# TeaVM can't do these JVM-only calls (found by the first real build):
def rc(s):
    s = s.replace('value = field.getInt(null);', 'value = 0;')
    s = s.replace('field.setInt(null, check.fieldValues[j]);', ';')
    s = s.replace('ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(args[k]));', 'Object stream = noStream();')
    helper = "\n\tprivate static Object noStream() throws ClassNotFoundException, InvalidClassException, StreamCorruptedException, OptionalDataException, IOException {\n\t\treturn null;\n\t}\n}"
    i = s.rstrip().rfind('}')
    s = s[:i] + helper + "\n"
    s = s.replace('params[k] = stream.readObject();', 'params[k] = stream;')
    return s
patch('rt4/ReflectionCheck.java', rc)
patch('rt4/GameShell.java', lambda s: s.replace('maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1048576L) + 1;', 'maxMemory = 256;'))
patch('shim/platform/Platforms.java', lambda s: s.replace('System.exit(code);', 'throw new IllegalStateException("client exit " + code);'))

print('assembled', OUT)

# --- debug logging for the JS5 loader (shows up in the on-screen log) ---
def js5_debug(s):
    import re
    s = re.sub(r'(catch \(@Pc\(\d+\) IOException ex\) \{)', r'\1\n\t\t\tweb.Js.log("js5 io error #" + this.errors + ": " + ex);', s)
    s = s.replace('if (matched == null) {\n\t\t\t\t\t\t\t\tthrow new IOException();',
                  'if (matched == null) {\n\t\t\t\t\t\t\t\tweb.Js.log("js5 unmatched header a=" + readLen + " g=" + j + " flag=" + headerByte + " len=" + compressedLen + " urgent=" + this.inFlightUrgentRequests.size() + " prefetch=" + this.inFlightPrefetchRequests.size());\n\t\t\t\t\t\t\t\tthrow new IOException();')
    # faster downloads: more requests in flight, more reads handled per tick
    s = s.replace('getPrefetchRequestCount() >= 20', 'getPrefetchRequestCount() >= 64')
    s = s.replace('getUrgentRequestCount() >= 20', 'getUrgentRequestCount() >= 64')
    s = s.replace('getPrefetchRequestCount() < 20', 'getPrefetchRequestCount() < 64')
    s = s.replace('iteration < 100; iteration++', 'iteration < 400; iteration++')
    return s
patch('rt4/Js5NetQueue.java', js5_debug)

# --- crash breadcrumbs: say which phase of the main loop / redraw threw ---
def client_crumbs(s):
    def wrap(call, name):
        return 'try { ' + call + ' } catch (RuntimeException ex) { web.Js.log("CRASH in ' + name + ': " + ex); throw ex; }'
    s = s.replace('LoginManager.rebuildMap();\n\t\t}\n\t\tif (gameState == 10)', wrap('LoginManager.rebuildMap();', 'rebuildMap') + '\n\t\t}\n\t\tif (gameState == 10)')
    s = s.replace('\t\t\tthis.mainUpdate();\n\t\t\tCreateManager.loop();\n\t\t\tLoginManager.loopAuto();\n\t\t\tLoginManager.loop();',
        '\t\t\t' + wrap('this.mainUpdate();', 'mainUpdate') + '\n\t\t\t' + wrap('CreateManager.loop();', 'CreateManager.loop') + '\n\t\t\t' + wrap('LoginManager.loopAuto();', 'loopAuto') + '\n\t\t\t' + wrap('LoginManager.loop();', 'LoginManager.loop10'))
    s = s.replace('} else if (gameState == 30) {\n\t\t\tProtocol.loop();', '} else if (gameState == 30) {\n\t\t\t' + wrap('Protocol.loop();', 'Protocol.loop'))
    s = s.replace('\t\t\tLoginManager.loop();\n\t\t\tif (LoginManager.reply != -3)', '\t\t\t' + wrap('LoginManager.loop();', 'LoginManager.loop40') + '\n\t\t\tif (LoginManager.reply != -3)')
    s = s.replace('protected final void mainRedraw() {',
        'protected final void mainRedraw() {\n\t\ttry { mainRedraw0(); } catch (RuntimeException ex) { web.Js.log("CRASH in mainRedraw gs=" + gameState + ": " + ex); throw ex; }\n\t}\n\n\tprotected final void mainRedraw0() {', 1)
    return s
patch('rt4/client.java', client_crumbs)

# --- breadcrumbs inside LoginManager.rebuildMap (runs once per login) ---
def rm_crumbs(s):
    anchors = [
        'client.audioLoop();\n\t\tclient.unload();\n\t\t@Pc(420)',
        'SceneGraph.init(GlRenderer.enabled',
        'for (i = 0; i < 4; i++) {\n\t\t\tPathFinder.collisionMaps[i].clear();',
        'AreaSoundManager.clear(false);',
        'System.gc();\n\t\tClientProt.ping(true);\n\t\tSceneGraph.load(false);',
        'readStaticTerrain(false);\n\t\t\tClientProt.ping(true);\n\t\t\tif (GlRenderer.enabled) {\n\t\t\t\ti = PlayerList',
        'readStaticLocs(false);\n\t\t\tif (npcSpawnsFilesBuffer',
        'decodeNpcFiles();',
        'readDynamicTerrain(false);',
        'readDynamicLocs(false);',
        'SceneGraph.buildScene(PathFinder.collisionMaps, false);',
        'SceneGraph.unload();\n\t\tif (GlRenderer.enabled && hasUnderWaterMap)',
        'for (chunkX = 0; chunkX < 104; chunkX++) {\n\t\t\tfor (chunkY = 0; chunkY < 104; chunkY++) {\n\t\t\t\tProtocol.spawnGroundObject',
        'ScriptRunner.updateRoofRemovalMode();',
        'ChangeLocRequest.flush();',
        'WorldMap.restorePreviousMap();',
    ]
    for n, a in enumerate(anchors):
        if a not in s:
            web_log = None
            print('rm_crumbs: anchor missing', n, a[:40])
            continue
        s = s.replace(a, 'web.Js.log("rm@%d");\n\t\t' % n + a, 1)
    return s
patch('rt4/LoginManager.java', rm_crumbs)

# --- 3-D arrays via explicit loops, plus breadcrumbs inside SceneGraph.init ---
def sg3d(s):
    import re
    def rep(m):
        t = m.group(1)
        fn = {'int': 'ints', 'byte': 'bytes', 'Tile': 'tiles', 'LinkedList': 'lists'}[t]
        return 'Arr3.%s(%s, %s, %s)' % (fn, m.group(2), m.group(3), m.group(4))
    s = re.sub(r'new (int|byte|Tile|LinkedList)\[([^\]\[]+)\]\[([^\]\[]+)\]\[([^\]\[]+)\]', rep, s)
    n = [0]
    def crumb(m):
        n[0] += 1
        return 'web.Js.log("sgi@%d");\n\t\t%s' % (n[0], m.group(0))
    head = s.index('public static void init(')
    body_end = s.index('public static long getWallKey')
    part = s[head:body_end]
    part = re.sub(r'\n\t\t(?=\S)', lambda m: '\n\t\tweb.Js.log("sgi@%d");\n\t\t' % (n.__setitem__(0, n[0] + 1) or n[0]), part)
    return s[:head] + part + s[body_end:]
patch('rt4/SceneGraph.java', sg3d)

# --- every remaining 3-D array allocation goes through the loop builders ---
def all3d():
    import re, glob
    pat = re.compile(r'new (int|byte|Tile|LinkedList)\[([^\]\[]+)\]\[([^\]\[]+)\]\[([^\]\[]+)\]')
    fns = {'int': 'ints', 'byte': 'bytes', 'Tile': 'tiles', 'LinkedList': 'lists'}
    for p in glob.glob(os.path.join(OUT, 'rt4', '*.java')):
        if p.endswith('Arr3.java'):
            continue
        s = read(p)
        n = pat.sub(lambda m: 'Arr3.%s(%s, %s, %s)' % (fns[m.group(1)], m.group(2), m.group(3), m.group(4)), s)
        n = re.sub(r'new (int|byte)\[([^\]\[]+)\]\[([^\]\[]+)\]\[\]', lambda m: 'Arr3.%sP(%s, %s)' % (m.group(1) + 's', m.group(2), m.group(3)), n)
        if n != s:
            write(p, n)
all3d()

# tell the page which game state we are in (hides the keyboard on taps in-game)
patch('rt4/client.java', lambda s: s.replace('public static void setGameState(@OriginalArg(0) int state) {', 'public static void setGameState(@OriginalArg(0) int state) {\n\t\tweb.Js.gameState(state);', 1))

# --- bridge for the web login screen (login.js): game state out, login requests in ---
def savedacct(s):
    a = '        frames++;\n'
    assert a in s
    b = a + (
        '\t\tif (client.gameState != 30 || (frames & 7) == 0) {\n'
        '\t\t\tweb.Js.loginState(client.gameState, client.mainLoadPercentage, client.gameState == 30 || client.mainLoadSecondaryText == null ? "" : client.mainLoadSecondaryText.toString(), client.mainLoadState, LoginManager.step, LoginManager.hopStep, LoginManager.reply, reconnecting, intentionalLogout, frames);\n'
        '\t\t}\n'
        '\t\tString webLogin = web.Js.takeLogin();\n'
        '\t\tif (webLogin.length() > 0) {\n'
        '\t\t\tint i1 = webLogin.indexOf((char) 1), i2 = webLogin.lastIndexOf((char) 1);\n'
        '\t\t\trequest(webLogin.substring(0, i1), webLogin.substring(i1 + 1, i2), webLogin.charAt(i2 + 1) == (char) 49);\n'
        '\t\t}\n')
    return s.replace(a, b, 1)
patch('rt4/SavedAccount.java', savedacct)

# centre windows opened over the game (bank, dice, music...) on the real screen size
patch('rt4/client.java', lambda s: s.replace('MobileLayout.apply(); SavedAccount.tick();', 'MobileLayout.apply(); WebCenter.apply(); SavedAccount.tick();', 1))

# lag: the software renderer draws 25 tiles in every direction; 18 is plenty on a phone and much cheaper when zoomed out
patch('rt4/LoginManager.java', lambda s: s.replace('GlobalConfig.TILE_DISTANCE : 25, hasUnderWaterMap', 'GlobalConfig.TILE_DISTANCE : 18, hasUnderWaterMap', 1))

# lag: low-detail graphics defaults for the software renderer in the browser
def perfprefs(s):
    a = "\t\ttry {\n\t\t\tif (file != null) {\n\t\t\t\tfile.close();"
    assert a in s
    b = ("\t\thighDetailTextures = false; manyGroundTextures = false; characterShadowsOn = false; sceneryShadowsType = 0;\n"
         "\t\tflickeringEffectsOn = false; highDetailLighting = false; highWaterDetail = false; fogEnabled = false; antiAliasingMode = 0;\n")
    return s.replace(a, b + a, 1)
patch('rt4/Preferences.java', perfprefs)

# drags that start on a window (bank, dice...) are mouse drags (move items), not camera turns
patch('rt4/MobileLayout.java', lambda s: s.replace("        if (panelOpen && x >= panelX", "        if (WebCenter.over(x, y)) return false;\n        if (panelOpen && x >= panelX", 1))
